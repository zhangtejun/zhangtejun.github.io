/*
 *    Copyright 2006-2020 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.generator.codegen.mybatis3.javamapper;


import org.mybatis.generator.api.CommentGenerator;
import org.mybatis.generator.api.dom.java.*;
import org.mybatis.generator.codegen.AbstractJavaClientGenerator;
import org.mybatis.generator.codegen.AbstractXmlGenerator;
import org.mybatis.generator.codegen.mybatis3.javamapper.elements.AbstractJavaMapperMethodGenerator;
import org.mybatis.generator.codegen.mybatis3.xmlmapper.XMLMapperGenerator;
import org.mybatis.generator.config.PropertyRegistry;
import org.mybatis.generator.internal.util.JavaBeansUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import static org.mybatis.generator.internal.util.StringUtility.stringHasValue;
import static org.mybatis.generator.internal.util.messages.Messages.getString;

public class JavaHttpDownloadGenerator extends AbstractJavaClientGenerator {
    public static ConcurrentHashMap<String,Interface> map = new ConcurrentHashMap<>();
    public JavaHttpDownloadGenerator(String project) {
        this(project, true);
    }

    public JavaHttpDownloadGenerator(String project, boolean requiresMatchedXMLGenerator) {
        super(project, requiresMatchedXMLGenerator);
    }

    @Override
    public List<CompilationUnit> getCompilationUnits() {
        progressCallback.startTask(getString("new_Progress.17", //$NON-NLS-1$
                introspectedTable.getFullyQualifiedTable().toString()));
        CommentGenerator commentGenerator = context.getCommentGenerator();


        // 实现类全路径
        String interfaceType = introspectedTable.getServiceInterfaceType();
        int i = interfaceType.lastIndexOf(".");
        String pk = interfaceType.substring(0,i);
        String su = interfaceType.substring(i+1);

        //
        String domainObjectName = introspectedTable.getFullyQualifiedTable().getDomainObjectName();


        FullyQualifiedJavaType type = new FullyQualifiedJavaType(pk + ".http.IDownload"+domainObjectName+"HttpService");
        // 类路径
/*

        FullyQualifiedJavaType type = new FullyQualifiedJavaType(
                introspectedTable.getServiceInterfaceType());
*/


        Interface interfaze = new Interface(type);
        interfaze.setVisibility(JavaVisibility.PUBLIC);
        interfaze.addAnnotation("@CloudService");
        commentGenerator.addJavaFileComment(interfaze);

        String rootInterface = introspectedTable
                .getTableConfigurationProperty(PropertyRegistry.ANY_ROOT_INTERFACE);
        if (!stringHasValue(rootInterface)) {
            rootInterface = context.getJavaClientGeneratorConfiguration()
                    .getProperty(PropertyRegistry.ANY_ROOT_INTERFACE);
        }

        if (stringHasValue(rootInterface)) {
            FullyQualifiedJavaType fqjt = new FullyQualifiedJavaType(
                    rootInterface);
            interfaze.addSuperInterface(fqjt);
            // interfaze.addImportedType(fqjt);
        }
        interfaze.addImportedType(new FullyQualifiedJavaType("com.hundsun.jrescloud.rpc.annotation.CloudFunction"));
        interfaze.addImportedType(new FullyQualifiedJavaType("com.hundsun.jrescloud.rpc.annotation.CloudService"));
        interfaze.addImportedType(new FullyQualifiedJavaType("com.hundsun.amc.model.RequestDTO"));

     /*   addListMethod(interfaze);
        addInsertBatchMethod(interfaze);
        addGetMethod(interfaze);
        addSaveMethod(interfaze);
        addDeleteMethod(interfaze);
        addUpdateMethod(interfaze);*/

        addDownloadHttp(interfaze);
        map.put(type.getShortName(),interfaze);
        List<CompilationUnit> answer = new ArrayList<CompilationUnit>();
      /*  if (context.getPlugins().clientGenerated(interfaze,
                introspectedTable)) {

        }*/
        answer.add(interfaze);

        List<CompilationUnit> extraCompilationUnits = getExtraCompilationUnits();
        if (extraCompilationUnits != null) {
            answer.addAll(extraCompilationUnits);
        }

        return answer;
    }

    private void addDownloadHttp(Interface interfaze) {

        Method method = new Method("download"+introspectedTable.getRules().calculateAllFieldsClass().getShortName()+"Http");
        method.setVisibility(JavaVisibility.PUBLIC);
        method.addAnnotation("@CloudFunction( apiUrl = \""+introspectedTable.getRules().calculateAllFieldsClass().getShortName()+ JavaBeansUtil.getFirstCharacterUppercase(method.getName())+"\", desc = \""+JavaBeansUtil.getFirstCharacterUppercase(method.getName())+"下载接口\" ,functionId = \"XXXXX\")");
        method.setAbstract(true);
        FullyQualifiedJavaType type = new FullyQualifiedJavaType(context.getJavaServiceGeneratorConfiguration().getDtoDirectory()+ introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "InputDTO");
        FullyQualifiedJavaType request = new FullyQualifiedJavaType("com.hundsun.amc.model.RequestDTO");
        request.addTypeArgument(new FullyQualifiedJavaType(type.getShortName()));
        method.addParameter(new Parameter(request,"inputParam"));
        interfaze.addImportedType(type);
        // set OutputDTO

        FullyQualifiedJavaType first = new FullyQualifiedJavaType("org.springframework.http.ResponseEntity");
        first.addTypeArgument(new FullyQualifiedJavaType("byte[]"));
        interfaze.addImportedType(first);
        method.setReturnType(first);
        interfaze.addMethod(method);
    }

    public void addListMethod(Interface interfaze){
        FullyQualifiedJavaType mapperType= new FullyQualifiedJavaType(introspectedTable.getMyBatis3JavaMapperType());
        Method method = new Method("list");
        method.setVisibility(JavaVisibility.PUBLIC);
        method.addAnnotation("@CloudFunction( functionId = \"XXXXXX\", desc = \"XXXXXXXX说明\" )");
        method.setName("list");
        method.setAbstract(true);


        FullyQualifiedJavaType type = new FullyQualifiedJavaType(context.getJavaServiceGeneratorConfiguration().getDtoDirectory() + introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "InputDTO");

        FullyQualifiedJavaType request = new FullyQualifiedJavaType("com.hundsun.amc.model.RequestDTO");
        request.addTypeArgument(new FullyQualifiedJavaType(type.getShortName()));
        method.addParameter(new Parameter(request,"inputParam"));

        interfaze.addImportedType(type);
        FullyQualifiedJavaType resultType = new FullyQualifiedJavaType("com.github.pagehelper.PageInfo");
        // set OutputDTO
        FullyQualifiedJavaType type2 = new FullyQualifiedJavaType(context.getJavaServiceGeneratorConfiguration().getDtoDirectory()+ introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "OutputDTO");
        interfaze.addImportedType(type2);
        resultType.addTypeArgument(type2);

        FullyQualifiedJavaType first = new FullyQualifiedJavaType("com.hundsun.jrescloud.rpc.result.RpcResultDTO");
        first.addTypeArgument(resultType);
        interfaze.addImportedType(first);
        method.setReturnType(first);
        interfaze.addMethod(method);
    }
    public void addGetMethod(Interface interfaze){
        Method method = new Method("get");
        method.setAbstract(true);
        interfaze.addImportedType(new FullyQualifiedJavaType("java.lang.String"));
        interfaze.addImportedType(new FullyQualifiedJavaType("java.lang.Void"));
        FullyQualifiedJavaType first = new FullyQualifiedJavaType("com.hundsun.jrescloud.rpc.result.RpcResultDTO");
        // set OutputDTO
        FullyQualifiedJavaType type2 = new FullyQualifiedJavaType(context.getJavaServiceGeneratorConfiguration().getDtoDirectory()+ introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "OutputDTO");
        interfaze.addImportedType(type2);
        first.addTypeArgument(type2);

        method.setReturnType(first);
        FullyQualifiedJavaType request = new FullyQualifiedJavaType("com.hundsun.amc.model.RequestDTO");
        request.addTypeArgument(FullyQualifiedJavaType.getStringInstance());
        method.addParameter(new Parameter(request,"id"));
        method.addAnnotation("@CloudFunction(functionId = \"XXXXXX\", desc = \"XXXXXXXX说明\")");
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName("get");
        interfaze.addMethod(method);


    }
    public void addSaveMethod(Interface interfaze){
        Method method = new Method("save");
        // method.addParameter(new Parameter(introspectedTable.getRules().calculateAllFieldsClass(),"toDB"));
        method.addAnnotation("@CloudFunction(functionId = \"XXXXXX\", desc = \"XXXXXXXX说明\")");
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName("save");
        method.setAbstract(true);

        FullyQualifiedJavaType type = new FullyQualifiedJavaType(context.getJavaServiceGeneratorConfiguration().getDtoDirectory() + introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "InputDTO");
        FullyQualifiedJavaType request = new FullyQualifiedJavaType("com.hundsun.amc.model.RequestDTO");
        request.addTypeArgument(new FullyQualifiedJavaType(type.getShortName()));
        method.addParameter(new Parameter(request,"inputParam"));
        interfaze.addImportedType(type);

        interfaze.addImportedType(new FullyQualifiedJavaType("java.lang.Void"));
        FullyQualifiedJavaType first = new FullyQualifiedJavaType("com.hundsun.jrescloud.rpc.result.RpcResultDTO");
        first.addTypeArgument(new FullyQualifiedJavaType("Void"));
        method.setReturnType(first);

        interfaze.addMethod(method);
    }
    public void addDeleteMethod(Interface interfaze){
        Method method = new Method("delete");
        ///method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(),"id"));

        FullyQualifiedJavaType type = new FullyQualifiedJavaType(context.getJavaServiceGeneratorConfiguration().getDtoDirectory()+ introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "InputDTO");
        FullyQualifiedJavaType request = new FullyQualifiedJavaType("com.hundsun.amc.model.RequestDTO");
        request.addTypeArgument(new FullyQualifiedJavaType(type.getShortName()));
        method.addParameter(new Parameter(request,"inputParam"));
        interfaze.addImportedType(type);

        method.addAnnotation("@CloudFunction(functionId = \"XXXXXX\", desc = \"XXXXXXXX说明\")");
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName("delete");
        method.setAbstract(true);
        interfaze.addImportedType(new FullyQualifiedJavaType("java.lang.Void"));
        FullyQualifiedJavaType first = new FullyQualifiedJavaType("com.hundsun.jrescloud.rpc.result.RpcResultDTO");
        first.addTypeArgument(new FullyQualifiedJavaType("Void"));
        method.setReturnType(first);
        interfaze.addMethod(method);
    }
    public void addUpdateMethod(Interface interfaze){
        Method method = new Method("update");
        // method.addParameter(new Parameter(introspectedTable.getRules().calculateAllFieldsClass(),"toDB"));

        FullyQualifiedJavaType type = new FullyQualifiedJavaType(context.getJavaServiceGeneratorConfiguration().getDtoDirectory() + introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "InputDTO");
        FullyQualifiedJavaType request = new FullyQualifiedJavaType("com.hundsun.amc.model.RequestDTO");
        request.addTypeArgument(new FullyQualifiedJavaType(type.getShortName()));
        method.addParameter(new Parameter(request,"inputParam"));
        interfaze.addImportedType(type);

        method.addAnnotation("@CloudFunction( functionId = \"XXXXXX\", desc = \"XXXXXXXX说明\" )");
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName("update");
        method.setAbstract(true);
        interfaze.addImportedType(new FullyQualifiedJavaType("java.lang.Void"));
        FullyQualifiedJavaType first = new FullyQualifiedJavaType("com.hundsun.jrescloud.rpc.result.RpcResultDTO");
        first.addTypeArgument(new FullyQualifiedJavaType("Void"));
        method.setReturnType(first);
        interfaze.addMethod(method);
    }
    protected void initializeAndExecuteGenerator(
            AbstractJavaMapperMethodGenerator methodGenerator,
            Interface interfaze) {
        methodGenerator.setContext(context);
        methodGenerator.setIntrospectedTable(introspectedTable);
        methodGenerator.setProgressCallback(progressCallback);
        methodGenerator.setWarnings(warnings);
        methodGenerator.addInterfaceElements(interfaze);
    }
    protected void addInsertBatchMethod(Interface interfaze) {
        if (introspectedTable.getRules().generateInsertBatch()) {
            AbstractJavaMapperMethodGenerator methodGenerator = new InsertBatchMethodGenerator(false,introspectedTable.getRules().calculateAllFieldsClass().getShortName()+"InputDTO");
            initializeAndExecuteGenerator(methodGenerator, interfaze);
        }
    }


    public List<CompilationUnit> getExtraCompilationUnits() {
        return Collections.emptyList();
    }

    @Override
    public AbstractXmlGenerator getMatchedXMLGenerator() {
        return new XMLMapperGenerator();
    }
}
