/*
 *    Copyright 2006-2020 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.generator.test1;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class WbinsInsSourceCriteria {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public WbinsInsSourceCriteria() {
        oredCriteria = new ArrayList<>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andSeqidIsNull() {
            addCriterion("SEQID is null");
            return (Criteria) this;
        }

        public Criteria andSeqidIsNotNull() {
            addCriterion("SEQID is not null");
            return (Criteria) this;
        }

        public Criteria andSeqidEqualTo(String value) {
            addCriterion("SEQID =", value, "seqid");
            return (Criteria) this;
        }

        public Criteria andSeqidNotEqualTo(String value) {
            addCriterion("SEQID <>", value, "seqid");
            return (Criteria) this;
        }

        public Criteria andSeqidGreaterThan(String value) {
            addCriterion("SEQID >", value, "seqid");
            return (Criteria) this;
        }

        public Criteria andSeqidGreaterThanOrEqualTo(String value) {
            addCriterion("SEQID >=", value, "seqid");
            return (Criteria) this;
        }

        public Criteria andSeqidLessThan(String value) {
            addCriterion("SEQID <", value, "seqid");
            return (Criteria) this;
        }

        public Criteria andSeqidLessThanOrEqualTo(String value) {
            addCriterion("SEQID <=", value, "seqid");
            return (Criteria) this;
        }

        public Criteria andSeqidLike(String value) {
            addCriterion("SEQID like", value, "seqid");
            return (Criteria) this;
        }

        public Criteria andSeqidNotLike(String value) {
            addCriterion("SEQID not like", value, "seqid");
            return (Criteria) this;
        }

        public Criteria andSeqidIn(List<String> values) {
            addCriterion("SEQID in", values, "seqid");
            return (Criteria) this;
        }

        public Criteria andSeqidNotIn(List<String> values) {
            addCriterion("SEQID not in", values, "seqid");
            return (Criteria) this;
        }

        public Criteria andSeqidBetween(String value1, String value2) {
            addCriterion("SEQID between", value1, value2, "seqid");
            return (Criteria) this;
        }

        public Criteria andSeqidNotBetween(String value1, String value2) {
            addCriterion("SEQID not between", value1, value2, "seqid");
            return (Criteria) this;
        }

        public Criteria andInstrNameIsNull() {
            addCriterion("INSTR_NAME is null");
            return (Criteria) this;
        }

        public Criteria andInstrNameIsNotNull() {
            addCriterion("INSTR_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andInstrNameEqualTo(String value) {
            addCriterion("INSTR_NAME =", value, "instrName");
            return (Criteria) this;
        }

        public Criteria andInstrNameNotEqualTo(String value) {
            addCriterion("INSTR_NAME <>", value, "instrName");
            return (Criteria) this;
        }

        public Criteria andInstrNameGreaterThan(String value) {
            addCriterion("INSTR_NAME >", value, "instrName");
            return (Criteria) this;
        }

        public Criteria andInstrNameGreaterThanOrEqualTo(String value) {
            addCriterion("INSTR_NAME >=", value, "instrName");
            return (Criteria) this;
        }

        public Criteria andInstrNameLessThan(String value) {
            addCriterion("INSTR_NAME <", value, "instrName");
            return (Criteria) this;
        }

        public Criteria andInstrNameLessThanOrEqualTo(String value) {
            addCriterion("INSTR_NAME <=", value, "instrName");
            return (Criteria) this;
        }

        public Criteria andInstrNameLike(String value) {
            addCriterion("INSTR_NAME like", value, "instrName");
            return (Criteria) this;
        }

        public Criteria andInstrNameNotLike(String value) {
            addCriterion("INSTR_NAME not like", value, "instrName");
            return (Criteria) this;
        }

        public Criteria andInstrNameIn(List<String> values) {
            addCriterion("INSTR_NAME in", values, "instrName");
            return (Criteria) this;
        }

        public Criteria andInstrNameNotIn(List<String> values) {
            addCriterion("INSTR_NAME not in", values, "instrName");
            return (Criteria) this;
        }

        public Criteria andInstrNameBetween(String value1, String value2) {
            addCriterion("INSTR_NAME between", value1, value2, "instrName");
            return (Criteria) this;
        }

        public Criteria andInstrNameNotBetween(String value1, String value2) {
            addCriterion("INSTR_NAME not between", value1, value2, "instrName");
            return (Criteria) this;
        }

        public Criteria andInstrHklbIsNull() {
            addCriterion("INSTR_HKLB is null");
            return (Criteria) this;
        }

        public Criteria andInstrHklbIsNotNull() {
            addCriterion("INSTR_HKLB is not null");
            return (Criteria) this;
        }

        public Criteria andInstrHklbEqualTo(String value) {
            addCriterion("INSTR_HKLB =", value, "instrHklb");
            return (Criteria) this;
        }

        public Criteria andInstrHklbNotEqualTo(String value) {
            addCriterion("INSTR_HKLB <>", value, "instrHklb");
            return (Criteria) this;
        }

        public Criteria andInstrHklbGreaterThan(String value) {
            addCriterion("INSTR_HKLB >", value, "instrHklb");
            return (Criteria) this;
        }

        public Criteria andInstrHklbGreaterThanOrEqualTo(String value) {
            addCriterion("INSTR_HKLB >=", value, "instrHklb");
            return (Criteria) this;
        }

        public Criteria andInstrHklbLessThan(String value) {
            addCriterion("INSTR_HKLB <", value, "instrHklb");
            return (Criteria) this;
        }

        public Criteria andInstrHklbLessThanOrEqualTo(String value) {
            addCriterion("INSTR_HKLB <=", value, "instrHklb");
            return (Criteria) this;
        }

        public Criteria andInstrHklbLike(String value) {
            addCriterion("INSTR_HKLB like", value, "instrHklb");
            return (Criteria) this;
        }

        public Criteria andInstrHklbNotLike(String value) {
            addCriterion("INSTR_HKLB not like", value, "instrHklb");
            return (Criteria) this;
        }

        public Criteria andInstrHklbIn(List<String> values) {
            addCriterion("INSTR_HKLB in", values, "instrHklb");
            return (Criteria) this;
        }

        public Criteria andInstrHklbNotIn(List<String> values) {
            addCriterion("INSTR_HKLB not in", values, "instrHklb");
            return (Criteria) this;
        }

        public Criteria andInstrHklbBetween(String value1, String value2) {
            addCriterion("INSTR_HKLB between", value1, value2, "instrHklb");
            return (Criteria) this;
        }

        public Criteria andInstrHklbNotBetween(String value1, String value2) {
            addCriterion("INSTR_HKLB not between", value1, value2, "instrHklb");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankCodeIsNull() {
            addCriterion("SETTLE_OUT_BANK_CODE is null");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankCodeIsNotNull() {
            addCriterion("SETTLE_OUT_BANK_CODE is not null");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankCodeEqualTo(String value) {
            addCriterion("SETTLE_OUT_BANK_CODE =", value, "settleOutBankCode");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankCodeNotEqualTo(String value) {
            addCriterion("SETTLE_OUT_BANK_CODE <>", value, "settleOutBankCode");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankCodeGreaterThan(String value) {
            addCriterion("SETTLE_OUT_BANK_CODE >", value, "settleOutBankCode");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankCodeGreaterThanOrEqualTo(String value) {
            addCriterion("SETTLE_OUT_BANK_CODE >=", value, "settleOutBankCode");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankCodeLessThan(String value) {
            addCriterion("SETTLE_OUT_BANK_CODE <", value, "settleOutBankCode");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankCodeLessThanOrEqualTo(String value) {
            addCriterion("SETTLE_OUT_BANK_CODE <=", value, "settleOutBankCode");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankCodeLike(String value) {
            addCriterion("SETTLE_OUT_BANK_CODE like", value, "settleOutBankCode");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankCodeNotLike(String value) {
            addCriterion("SETTLE_OUT_BANK_CODE not like", value, "settleOutBankCode");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankCodeIn(List<String> values) {
            addCriterion("SETTLE_OUT_BANK_CODE in", values, "settleOutBankCode");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankCodeNotIn(List<String> values) {
            addCriterion("SETTLE_OUT_BANK_CODE not in", values, "settleOutBankCode");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankCodeBetween(String value1, String value2) {
            addCriterion("SETTLE_OUT_BANK_CODE between", value1, value2, "settleOutBankCode");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankCodeNotBetween(String value1, String value2) {
            addCriterion("SETTLE_OUT_BANK_CODE not between", value1, value2, "settleOutBankCode");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankAccIsNull() {
            addCriterion("SETTLE_OUT_BANK_ACC is null");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankAccIsNotNull() {
            addCriterion("SETTLE_OUT_BANK_ACC is not null");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankAccEqualTo(String value) {
            addCriterion("SETTLE_OUT_BANK_ACC =", value, "settleOutBankAcc");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankAccNotEqualTo(String value) {
            addCriterion("SETTLE_OUT_BANK_ACC <>", value, "settleOutBankAcc");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankAccGreaterThan(String value) {
            addCriterion("SETTLE_OUT_BANK_ACC >", value, "settleOutBankAcc");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankAccGreaterThanOrEqualTo(String value) {
            addCriterion("SETTLE_OUT_BANK_ACC >=", value, "settleOutBankAcc");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankAccLessThan(String value) {
            addCriterion("SETTLE_OUT_BANK_ACC <", value, "settleOutBankAcc");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankAccLessThanOrEqualTo(String value) {
            addCriterion("SETTLE_OUT_BANK_ACC <=", value, "settleOutBankAcc");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankAccLike(String value) {
            addCriterion("SETTLE_OUT_BANK_ACC like", value, "settleOutBankAcc");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankAccNotLike(String value) {
            addCriterion("SETTLE_OUT_BANK_ACC not like", value, "settleOutBankAcc");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankAccIn(List<String> values) {
            addCriterion("SETTLE_OUT_BANK_ACC in", values, "settleOutBankAcc");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankAccNotIn(List<String> values) {
            addCriterion("SETTLE_OUT_BANK_ACC not in", values, "settleOutBankAcc");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankAccBetween(String value1, String value2) {
            addCriterion("SETTLE_OUT_BANK_ACC between", value1, value2, "settleOutBankAcc");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankAccNotBetween(String value1, String value2) {
            addCriterion("SETTLE_OUT_BANK_ACC not between", value1, value2, "settleOutBankAcc");
            return (Criteria) this;
        }

        public Criteria andSettleOutAccNameIsNull() {
            addCriterion("SETTLE_OUT_ACC_NAME is null");
            return (Criteria) this;
        }

        public Criteria andSettleOutAccNameIsNotNull() {
            addCriterion("SETTLE_OUT_ACC_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andSettleOutAccNameEqualTo(String value) {
            addCriterion("SETTLE_OUT_ACC_NAME =", value, "settleOutAccName");
            return (Criteria) this;
        }

        public Criteria andSettleOutAccNameNotEqualTo(String value) {
            addCriterion("SETTLE_OUT_ACC_NAME <>", value, "settleOutAccName");
            return (Criteria) this;
        }

        public Criteria andSettleOutAccNameGreaterThan(String value) {
            addCriterion("SETTLE_OUT_ACC_NAME >", value, "settleOutAccName");
            return (Criteria) this;
        }

        public Criteria andSettleOutAccNameGreaterThanOrEqualTo(String value) {
            addCriterion("SETTLE_OUT_ACC_NAME >=", value, "settleOutAccName");
            return (Criteria) this;
        }

        public Criteria andSettleOutAccNameLessThan(String value) {
            addCriterion("SETTLE_OUT_ACC_NAME <", value, "settleOutAccName");
            return (Criteria) this;
        }

        public Criteria andSettleOutAccNameLessThanOrEqualTo(String value) {
            addCriterion("SETTLE_OUT_ACC_NAME <=", value, "settleOutAccName");
            return (Criteria) this;
        }

        public Criteria andSettleOutAccNameLike(String value) {
            addCriterion("SETTLE_OUT_ACC_NAME like", value, "settleOutAccName");
            return (Criteria) this;
        }

        public Criteria andSettleOutAccNameNotLike(String value) {
            addCriterion("SETTLE_OUT_ACC_NAME not like", value, "settleOutAccName");
            return (Criteria) this;
        }

        public Criteria andSettleOutAccNameIn(List<String> values) {
            addCriterion("SETTLE_OUT_ACC_NAME in", values, "settleOutAccName");
            return (Criteria) this;
        }

        public Criteria andSettleOutAccNameNotIn(List<String> values) {
            addCriterion("SETTLE_OUT_ACC_NAME not in", values, "settleOutAccName");
            return (Criteria) this;
        }

        public Criteria andSettleOutAccNameBetween(String value1, String value2) {
            addCriterion("SETTLE_OUT_ACC_NAME between", value1, value2, "settleOutAccName");
            return (Criteria) this;
        }

        public Criteria andSettleOutAccNameNotBetween(String value1, String value2) {
            addCriterion("SETTLE_OUT_ACC_NAME not between", value1, value2, "settleOutAccName");
            return (Criteria) this;
        }

        public Criteria andSettleOutOpenBankIsNull() {
            addCriterion("SETTLE_OUT_OPEN_BANK is null");
            return (Criteria) this;
        }

        public Criteria andSettleOutOpenBankIsNotNull() {
            addCriterion("SETTLE_OUT_OPEN_BANK is not null");
            return (Criteria) this;
        }

        public Criteria andSettleOutOpenBankEqualTo(String value) {
            addCriterion("SETTLE_OUT_OPEN_BANK =", value, "settleOutOpenBank");
            return (Criteria) this;
        }

        public Criteria andSettleOutOpenBankNotEqualTo(String value) {
            addCriterion("SETTLE_OUT_OPEN_BANK <>", value, "settleOutOpenBank");
            return (Criteria) this;
        }

        public Criteria andSettleOutOpenBankGreaterThan(String value) {
            addCriterion("SETTLE_OUT_OPEN_BANK >", value, "settleOutOpenBank");
            return (Criteria) this;
        }

        public Criteria andSettleOutOpenBankGreaterThanOrEqualTo(String value) {
            addCriterion("SETTLE_OUT_OPEN_BANK >=", value, "settleOutOpenBank");
            return (Criteria) this;
        }

        public Criteria andSettleOutOpenBankLessThan(String value) {
            addCriterion("SETTLE_OUT_OPEN_BANK <", value, "settleOutOpenBank");
            return (Criteria) this;
        }

        public Criteria andSettleOutOpenBankLessThanOrEqualTo(String value) {
            addCriterion("SETTLE_OUT_OPEN_BANK <=", value, "settleOutOpenBank");
            return (Criteria) this;
        }

        public Criteria andSettleOutOpenBankLike(String value) {
            addCriterion("SETTLE_OUT_OPEN_BANK like", value, "settleOutOpenBank");
            return (Criteria) this;
        }

        public Criteria andSettleOutOpenBankNotLike(String value) {
            addCriterion("SETTLE_OUT_OPEN_BANK not like", value, "settleOutOpenBank");
            return (Criteria) this;
        }

        public Criteria andSettleOutOpenBankIn(List<String> values) {
            addCriterion("SETTLE_OUT_OPEN_BANK in", values, "settleOutOpenBank");
            return (Criteria) this;
        }

        public Criteria andSettleOutOpenBankNotIn(List<String> values) {
            addCriterion("SETTLE_OUT_OPEN_BANK not in", values, "settleOutOpenBank");
            return (Criteria) this;
        }

        public Criteria andSettleOutOpenBankBetween(String value1, String value2) {
            addCriterion("SETTLE_OUT_OPEN_BANK between", value1, value2, "settleOutOpenBank");
            return (Criteria) this;
        }

        public Criteria andSettleOutOpenBankNotBetween(String value1, String value2) {
            addCriterion("SETTLE_OUT_OPEN_BANK not between", value1, value2, "settleOutOpenBank");
            return (Criteria) this;
        }

        public Criteria andSettleInBankCodeIsNull() {
            addCriterion("SETTLE_IN_BANK_CODE is null");
            return (Criteria) this;
        }

        public Criteria andSettleInBankCodeIsNotNull() {
            addCriterion("SETTLE_IN_BANK_CODE is not null");
            return (Criteria) this;
        }

        public Criteria andSettleInBankCodeEqualTo(String value) {
            addCriterion("SETTLE_IN_BANK_CODE =", value, "settleInBankCode");
            return (Criteria) this;
        }

        public Criteria andSettleInBankCodeNotEqualTo(String value) {
            addCriterion("SETTLE_IN_BANK_CODE <>", value, "settleInBankCode");
            return (Criteria) this;
        }

        public Criteria andSettleInBankCodeGreaterThan(String value) {
            addCriterion("SETTLE_IN_BANK_CODE >", value, "settleInBankCode");
            return (Criteria) this;
        }

        public Criteria andSettleInBankCodeGreaterThanOrEqualTo(String value) {
            addCriterion("SETTLE_IN_BANK_CODE >=", value, "settleInBankCode");
            return (Criteria) this;
        }

        public Criteria andSettleInBankCodeLessThan(String value) {
            addCriterion("SETTLE_IN_BANK_CODE <", value, "settleInBankCode");
            return (Criteria) this;
        }

        public Criteria andSettleInBankCodeLessThanOrEqualTo(String value) {
            addCriterion("SETTLE_IN_BANK_CODE <=", value, "settleInBankCode");
            return (Criteria) this;
        }

        public Criteria andSettleInBankCodeLike(String value) {
            addCriterion("SETTLE_IN_BANK_CODE like", value, "settleInBankCode");
            return (Criteria) this;
        }

        public Criteria andSettleInBankCodeNotLike(String value) {
            addCriterion("SETTLE_IN_BANK_CODE not like", value, "settleInBankCode");
            return (Criteria) this;
        }

        public Criteria andSettleInBankCodeIn(List<String> values) {
            addCriterion("SETTLE_IN_BANK_CODE in", values, "settleInBankCode");
            return (Criteria) this;
        }

        public Criteria andSettleInBankCodeNotIn(List<String> values) {
            addCriterion("SETTLE_IN_BANK_CODE not in", values, "settleInBankCode");
            return (Criteria) this;
        }

        public Criteria andSettleInBankCodeBetween(String value1, String value2) {
            addCriterion("SETTLE_IN_BANK_CODE between", value1, value2, "settleInBankCode");
            return (Criteria) this;
        }

        public Criteria andSettleInBankCodeNotBetween(String value1, String value2) {
            addCriterion("SETTLE_IN_BANK_CODE not between", value1, value2, "settleInBankCode");
            return (Criteria) this;
        }

        public Criteria andSettleInBankAccIsNull() {
            addCriterion("SETTLE_IN_BANK_ACC is null");
            return (Criteria) this;
        }

        public Criteria andSettleInBankAccIsNotNull() {
            addCriterion("SETTLE_IN_BANK_ACC is not null");
            return (Criteria) this;
        }

        public Criteria andSettleInBankAccEqualTo(String value) {
            addCriterion("SETTLE_IN_BANK_ACC =", value, "settleInBankAcc");
            return (Criteria) this;
        }

        public Criteria andSettleInBankAccNotEqualTo(String value) {
            addCriterion("SETTLE_IN_BANK_ACC <>", value, "settleInBankAcc");
            return (Criteria) this;
        }

        public Criteria andSettleInBankAccGreaterThan(String value) {
            addCriterion("SETTLE_IN_BANK_ACC >", value, "settleInBankAcc");
            return (Criteria) this;
        }

        public Criteria andSettleInBankAccGreaterThanOrEqualTo(String value) {
            addCriterion("SETTLE_IN_BANK_ACC >=", value, "settleInBankAcc");
            return (Criteria) this;
        }

        public Criteria andSettleInBankAccLessThan(String value) {
            addCriterion("SETTLE_IN_BANK_ACC <", value, "settleInBankAcc");
            return (Criteria) this;
        }

        public Criteria andSettleInBankAccLessThanOrEqualTo(String value) {
            addCriterion("SETTLE_IN_BANK_ACC <=", value, "settleInBankAcc");
            return (Criteria) this;
        }

        public Criteria andSettleInBankAccLike(String value) {
            addCriterion("SETTLE_IN_BANK_ACC like", value, "settleInBankAcc");
            return (Criteria) this;
        }

        public Criteria andSettleInBankAccNotLike(String value) {
            addCriterion("SETTLE_IN_BANK_ACC not like", value, "settleInBankAcc");
            return (Criteria) this;
        }

        public Criteria andSettleInBankAccIn(List<String> values) {
            addCriterion("SETTLE_IN_BANK_ACC in", values, "settleInBankAcc");
            return (Criteria) this;
        }

        public Criteria andSettleInBankAccNotIn(List<String> values) {
            addCriterion("SETTLE_IN_BANK_ACC not in", values, "settleInBankAcc");
            return (Criteria) this;
        }

        public Criteria andSettleInBankAccBetween(String value1, String value2) {
            addCriterion("SETTLE_IN_BANK_ACC between", value1, value2, "settleInBankAcc");
            return (Criteria) this;
        }

        public Criteria andSettleInBankAccNotBetween(String value1, String value2) {
            addCriterion("SETTLE_IN_BANK_ACC not between", value1, value2, "settleInBankAcc");
            return (Criteria) this;
        }

        public Criteria andSettleInAccNameIsNull() {
            addCriterion("SETTLE_IN_ACC_NAME is null");
            return (Criteria) this;
        }

        public Criteria andSettleInAccNameIsNotNull() {
            addCriterion("SETTLE_IN_ACC_NAME is not null");
            return (Criteria) this;
        }

        public Criteria andSettleInAccNameEqualTo(String value) {
            addCriterion("SETTLE_IN_ACC_NAME =", value, "settleInAccName");
            return (Criteria) this;
        }

        public Criteria andSettleInAccNameNotEqualTo(String value) {
            addCriterion("SETTLE_IN_ACC_NAME <>", value, "settleInAccName");
            return (Criteria) this;
        }

        public Criteria andSettleInAccNameGreaterThan(String value) {
            addCriterion("SETTLE_IN_ACC_NAME >", value, "settleInAccName");
            return (Criteria) this;
        }

        public Criteria andSettleInAccNameGreaterThanOrEqualTo(String value) {
            addCriterion("SETTLE_IN_ACC_NAME >=", value, "settleInAccName");
            return (Criteria) this;
        }

        public Criteria andSettleInAccNameLessThan(String value) {
            addCriterion("SETTLE_IN_ACC_NAME <", value, "settleInAccName");
            return (Criteria) this;
        }

        public Criteria andSettleInAccNameLessThanOrEqualTo(String value) {
            addCriterion("SETTLE_IN_ACC_NAME <=", value, "settleInAccName");
            return (Criteria) this;
        }

        public Criteria andSettleInAccNameLike(String value) {
            addCriterion("SETTLE_IN_ACC_NAME like", value, "settleInAccName");
            return (Criteria) this;
        }

        public Criteria andSettleInAccNameNotLike(String value) {
            addCriterion("SETTLE_IN_ACC_NAME not like", value, "settleInAccName");
            return (Criteria) this;
        }

        public Criteria andSettleInAccNameIn(List<String> values) {
            addCriterion("SETTLE_IN_ACC_NAME in", values, "settleInAccName");
            return (Criteria) this;
        }

        public Criteria andSettleInAccNameNotIn(List<String> values) {
            addCriterion("SETTLE_IN_ACC_NAME not in", values, "settleInAccName");
            return (Criteria) this;
        }

        public Criteria andSettleInAccNameBetween(String value1, String value2) {
            addCriterion("SETTLE_IN_ACC_NAME between", value1, value2, "settleInAccName");
            return (Criteria) this;
        }

        public Criteria andSettleInAccNameNotBetween(String value1, String value2) {
            addCriterion("SETTLE_IN_ACC_NAME not between", value1, value2, "settleInAccName");
            return (Criteria) this;
        }

        public Criteria andSettleInOpenBankIsNull() {
            addCriterion("SETTLE_IN_OPEN_BANK is null");
            return (Criteria) this;
        }

        public Criteria andSettleInOpenBankIsNotNull() {
            addCriterion("SETTLE_IN_OPEN_BANK is not null");
            return (Criteria) this;
        }

        public Criteria andSettleInOpenBankEqualTo(String value) {
            addCriterion("SETTLE_IN_OPEN_BANK =", value, "settleInOpenBank");
            return (Criteria) this;
        }

        public Criteria andSettleInOpenBankNotEqualTo(String value) {
            addCriterion("SETTLE_IN_OPEN_BANK <>", value, "settleInOpenBank");
            return (Criteria) this;
        }

        public Criteria andSettleInOpenBankGreaterThan(String value) {
            addCriterion("SETTLE_IN_OPEN_BANK >", value, "settleInOpenBank");
            return (Criteria) this;
        }

        public Criteria andSettleInOpenBankGreaterThanOrEqualTo(String value) {
            addCriterion("SETTLE_IN_OPEN_BANK >=", value, "settleInOpenBank");
            return (Criteria) this;
        }

        public Criteria andSettleInOpenBankLessThan(String value) {
            addCriterion("SETTLE_IN_OPEN_BANK <", value, "settleInOpenBank");
            return (Criteria) this;
        }

        public Criteria andSettleInOpenBankLessThanOrEqualTo(String value) {
            addCriterion("SETTLE_IN_OPEN_BANK <=", value, "settleInOpenBank");
            return (Criteria) this;
        }

        public Criteria andSettleInOpenBankLike(String value) {
            addCriterion("SETTLE_IN_OPEN_BANK like", value, "settleInOpenBank");
            return (Criteria) this;
        }

        public Criteria andSettleInOpenBankNotLike(String value) {
            addCriterion("SETTLE_IN_OPEN_BANK not like", value, "settleInOpenBank");
            return (Criteria) this;
        }

        public Criteria andSettleInOpenBankIn(List<String> values) {
            addCriterion("SETTLE_IN_OPEN_BANK in", values, "settleInOpenBank");
            return (Criteria) this;
        }

        public Criteria andSettleInOpenBankNotIn(List<String> values) {
            addCriterion("SETTLE_IN_OPEN_BANK not in", values, "settleInOpenBank");
            return (Criteria) this;
        }

        public Criteria andSettleInOpenBankBetween(String value1, String value2) {
            addCriterion("SETTLE_IN_OPEN_BANK between", value1, value2, "settleInOpenBank");
            return (Criteria) this;
        }

        public Criteria andSettleInOpenBankNotBetween(String value1, String value2) {
            addCriterion("SETTLE_IN_OPEN_BANK not between", value1, value2, "settleInOpenBank");
            return (Criteria) this;
        }

        public Criteria andSettleInCnapsNoIsNull() {
            addCriterion("SETTLE_IN_CNAPS_NO is null");
            return (Criteria) this;
        }

        public Criteria andSettleInCnapsNoIsNotNull() {
            addCriterion("SETTLE_IN_CNAPS_NO is not null");
            return (Criteria) this;
        }

        public Criteria andSettleInCnapsNoEqualTo(String value) {
            addCriterion("SETTLE_IN_CNAPS_NO =", value, "settleInCnapsNo");
            return (Criteria) this;
        }

        public Criteria andSettleInCnapsNoNotEqualTo(String value) {
            addCriterion("SETTLE_IN_CNAPS_NO <>", value, "settleInCnapsNo");
            return (Criteria) this;
        }

        public Criteria andSettleInCnapsNoGreaterThan(String value) {
            addCriterion("SETTLE_IN_CNAPS_NO >", value, "settleInCnapsNo");
            return (Criteria) this;
        }

        public Criteria andSettleInCnapsNoGreaterThanOrEqualTo(String value) {
            addCriterion("SETTLE_IN_CNAPS_NO >=", value, "settleInCnapsNo");
            return (Criteria) this;
        }

        public Criteria andSettleInCnapsNoLessThan(String value) {
            addCriterion("SETTLE_IN_CNAPS_NO <", value, "settleInCnapsNo");
            return (Criteria) this;
        }

        public Criteria andSettleInCnapsNoLessThanOrEqualTo(String value) {
            addCriterion("SETTLE_IN_CNAPS_NO <=", value, "settleInCnapsNo");
            return (Criteria) this;
        }

        public Criteria andSettleInCnapsNoLike(String value) {
            addCriterion("SETTLE_IN_CNAPS_NO like", value, "settleInCnapsNo");
            return (Criteria) this;
        }

        public Criteria andSettleInCnapsNoNotLike(String value) {
            addCriterion("SETTLE_IN_CNAPS_NO not like", value, "settleInCnapsNo");
            return (Criteria) this;
        }

        public Criteria andSettleInCnapsNoIn(List<String> values) {
            addCriterion("SETTLE_IN_CNAPS_NO in", values, "settleInCnapsNo");
            return (Criteria) this;
        }

        public Criteria andSettleInCnapsNoNotIn(List<String> values) {
            addCriterion("SETTLE_IN_CNAPS_NO not in", values, "settleInCnapsNo");
            return (Criteria) this;
        }

        public Criteria andSettleInCnapsNoBetween(String value1, String value2) {
            addCriterion("SETTLE_IN_CNAPS_NO between", value1, value2, "settleInCnapsNo");
            return (Criteria) this;
        }

        public Criteria andSettleInCnapsNoNotBetween(String value1, String value2) {
            addCriterion("SETTLE_IN_CNAPS_NO not between", value1, value2, "settleInCnapsNo");
            return (Criteria) this;
        }

        public Criteria andFtAmountIsNull() {
            addCriterion("FT_AMOUNT is null");
            return (Criteria) this;
        }

        public Criteria andFtAmountIsNotNull() {
            addCriterion("FT_AMOUNT is not null");
            return (Criteria) this;
        }

        public Criteria andFtAmountEqualTo(BigDecimal value) {
            addCriterion("FT_AMOUNT =", value, "ftAmount");
            return (Criteria) this;
        }

        public Criteria andFtAmountNotEqualTo(BigDecimal value) {
            addCriterion("FT_AMOUNT <>", value, "ftAmount");
            return (Criteria) this;
        }

        public Criteria andFtAmountGreaterThan(BigDecimal value) {
            addCriterion("FT_AMOUNT >", value, "ftAmount");
            return (Criteria) this;
        }

        public Criteria andFtAmountGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("FT_AMOUNT >=", value, "ftAmount");
            return (Criteria) this;
        }

        public Criteria andFtAmountLessThan(BigDecimal value) {
            addCriterion("FT_AMOUNT <", value, "ftAmount");
            return (Criteria) this;
        }

        public Criteria andFtAmountLessThanOrEqualTo(BigDecimal value) {
            addCriterion("FT_AMOUNT <=", value, "ftAmount");
            return (Criteria) this;
        }

        public Criteria andFtAmountIn(List<BigDecimal> values) {
            addCriterion("FT_AMOUNT in", values, "ftAmount");
            return (Criteria) this;
        }

        public Criteria andFtAmountNotIn(List<BigDecimal> values) {
            addCriterion("FT_AMOUNT not in", values, "ftAmount");
            return (Criteria) this;
        }

        public Criteria andFtAmountBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("FT_AMOUNT between", value1, value2, "ftAmount");
            return (Criteria) this;
        }

        public Criteria andFtAmountNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("FT_AMOUNT not between", value1, value2, "ftAmount");
            return (Criteria) this;
        }

        public Criteria andSettleDateIsNull() {
            addCriterion("SETTLE_DATE is null");
            return (Criteria) this;
        }

        public Criteria andSettleDateIsNotNull() {
            addCriterion("SETTLE_DATE is not null");
            return (Criteria) this;
        }

        public Criteria andSettleDateEqualTo(String value) {
            addCriterion("SETTLE_DATE =", value, "settleDate");
            return (Criteria) this;
        }

        public Criteria andSettleDateNotEqualTo(String value) {
            addCriterion("SETTLE_DATE <>", value, "settleDate");
            return (Criteria) this;
        }

        public Criteria andSettleDateGreaterThan(String value) {
            addCriterion("SETTLE_DATE >", value, "settleDate");
            return (Criteria) this;
        }

        public Criteria andSettleDateGreaterThanOrEqualTo(String value) {
            addCriterion("SETTLE_DATE >=", value, "settleDate");
            return (Criteria) this;
        }

        public Criteria andSettleDateLessThan(String value) {
            addCriterion("SETTLE_DATE <", value, "settleDate");
            return (Criteria) this;
        }

        public Criteria andSettleDateLessThanOrEqualTo(String value) {
            addCriterion("SETTLE_DATE <=", value, "settleDate");
            return (Criteria) this;
        }

        public Criteria andSettleDateLike(String value) {
            addCriterion("SETTLE_DATE like", value, "settleDate");
            return (Criteria) this;
        }

        public Criteria andSettleDateNotLike(String value) {
            addCriterion("SETTLE_DATE not like", value, "settleDate");
            return (Criteria) this;
        }

        public Criteria andSettleDateIn(List<String> values) {
            addCriterion("SETTLE_DATE in", values, "settleDate");
            return (Criteria) this;
        }

        public Criteria andSettleDateNotIn(List<String> values) {
            addCriterion("SETTLE_DATE not in", values, "settleDate");
            return (Criteria) this;
        }

        public Criteria andSettleDateBetween(String value1, String value2) {
            addCriterion("SETTLE_DATE between", value1, value2, "settleDate");
            return (Criteria) this;
        }

        public Criteria andSettleDateNotBetween(String value1, String value2) {
            addCriterion("SETTLE_DATE not between", value1, value2, "settleDate");
            return (Criteria) this;
        }

        public Criteria andFtNoteIsNull() {
            addCriterion("FT_NOTE is null");
            return (Criteria) this;
        }

        public Criteria andFtNoteIsNotNull() {
            addCriterion("FT_NOTE is not null");
            return (Criteria) this;
        }

        public Criteria andFtNoteEqualTo(String value) {
            addCriterion("FT_NOTE =", value, "ftNote");
            return (Criteria) this;
        }

        public Criteria andFtNoteNotEqualTo(String value) {
            addCriterion("FT_NOTE <>", value, "ftNote");
            return (Criteria) this;
        }

        public Criteria andFtNoteGreaterThan(String value) {
            addCriterion("FT_NOTE >", value, "ftNote");
            return (Criteria) this;
        }

        public Criteria andFtNoteGreaterThanOrEqualTo(String value) {
            addCriterion("FT_NOTE >=", value, "ftNote");
            return (Criteria) this;
        }

        public Criteria andFtNoteLessThan(String value) {
            addCriterion("FT_NOTE <", value, "ftNote");
            return (Criteria) this;
        }

        public Criteria andFtNoteLessThanOrEqualTo(String value) {
            addCriterion("FT_NOTE <=", value, "ftNote");
            return (Criteria) this;
        }

        public Criteria andFtNoteLike(String value) {
            addCriterion("FT_NOTE like", value, "ftNote");
            return (Criteria) this;
        }

        public Criteria andFtNoteNotLike(String value) {
            addCriterion("FT_NOTE not like", value, "ftNote");
            return (Criteria) this;
        }

        public Criteria andFtNoteIn(List<String> values) {
            addCriterion("FT_NOTE in", values, "ftNote");
            return (Criteria) this;
        }

        public Criteria andFtNoteNotIn(List<String> values) {
            addCriterion("FT_NOTE not in", values, "ftNote");
            return (Criteria) this;
        }

        public Criteria andFtNoteBetween(String value1, String value2) {
            addCriterion("FT_NOTE between", value1, value2, "ftNote");
            return (Criteria) this;
        }

        public Criteria andFtNoteNotBetween(String value1, String value2) {
            addCriterion("FT_NOTE not between", value1, value2, "ftNote");
            return (Criteria) this;
        }

        public Criteria andManagerIsNull() {
            addCriterion("MANAGER is null");
            return (Criteria) this;
        }

        public Criteria andManagerIsNotNull() {
            addCriterion("MANAGER is not null");
            return (Criteria) this;
        }

        public Criteria andManagerEqualTo(String value) {
            addCriterion("MANAGER =", value, "manager");
            return (Criteria) this;
        }

        public Criteria andManagerNotEqualTo(String value) {
            addCriterion("MANAGER <>", value, "manager");
            return (Criteria) this;
        }

        public Criteria andManagerGreaterThan(String value) {
            addCriterion("MANAGER >", value, "manager");
            return (Criteria) this;
        }

        public Criteria andManagerGreaterThanOrEqualTo(String value) {
            addCriterion("MANAGER >=", value, "manager");
            return (Criteria) this;
        }

        public Criteria andManagerLessThan(String value) {
            addCriterion("MANAGER <", value, "manager");
            return (Criteria) this;
        }

        public Criteria andManagerLessThanOrEqualTo(String value) {
            addCriterion("MANAGER <=", value, "manager");
            return (Criteria) this;
        }

        public Criteria andManagerLike(String value) {
            addCriterion("MANAGER like", value, "manager");
            return (Criteria) this;
        }

        public Criteria andManagerNotLike(String value) {
            addCriterion("MANAGER not like", value, "manager");
            return (Criteria) this;
        }

        public Criteria andManagerIn(List<String> values) {
            addCriterion("MANAGER in", values, "manager");
            return (Criteria) this;
        }

        public Criteria andManagerNotIn(List<String> values) {
            addCriterion("MANAGER not in", values, "manager");
            return (Criteria) this;
        }

        public Criteria andManagerBetween(String value1, String value2) {
            addCriterion("MANAGER between", value1, value2, "manager");
            return (Criteria) this;
        }

        public Criteria andManagerNotBetween(String value1, String value2) {
            addCriterion("MANAGER not between", value1, value2, "manager");
            return (Criteria) this;
        }

        public Criteria andProductCodeIsNull() {
            addCriterion("PRODUCT_CODE is null");
            return (Criteria) this;
        }

        public Criteria andProductCodeIsNotNull() {
            addCriterion("PRODUCT_CODE is not null");
            return (Criteria) this;
        }

        public Criteria andProductCodeEqualTo(String value) {
            addCriterion("PRODUCT_CODE =", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotEqualTo(String value) {
            addCriterion("PRODUCT_CODE <>", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeGreaterThan(String value) {
            addCriterion("PRODUCT_CODE >", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeGreaterThanOrEqualTo(String value) {
            addCriterion("PRODUCT_CODE >=", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLessThan(String value) {
            addCriterion("PRODUCT_CODE <", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLessThanOrEqualTo(String value) {
            addCriterion("PRODUCT_CODE <=", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeLike(String value) {
            addCriterion("PRODUCT_CODE like", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotLike(String value) {
            addCriterion("PRODUCT_CODE not like", value, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeIn(List<String> values) {
            addCriterion("PRODUCT_CODE in", values, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotIn(List<String> values) {
            addCriterion("PRODUCT_CODE not in", values, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeBetween(String value1, String value2) {
            addCriterion("PRODUCT_CODE between", value1, value2, "productCode");
            return (Criteria) this;
        }

        public Criteria andProductCodeNotBetween(String value1, String value2) {
            addCriterion("PRODUCT_CODE not between", value1, value2, "productCode");
            return (Criteria) this;
        }

        public Criteria andInstrStatusIsNull() {
            addCriterion("INSTR_STATUS is null");
            return (Criteria) this;
        }

        public Criteria andInstrStatusIsNotNull() {
            addCriterion("INSTR_STATUS is not null");
            return (Criteria) this;
        }

        public Criteria andInstrStatusEqualTo(String value) {
            addCriterion("INSTR_STATUS =", value, "instrStatus");
            return (Criteria) this;
        }

        public Criteria andInstrStatusNotEqualTo(String value) {
            addCriterion("INSTR_STATUS <>", value, "instrStatus");
            return (Criteria) this;
        }

        public Criteria andInstrStatusGreaterThan(String value) {
            addCriterion("INSTR_STATUS >", value, "instrStatus");
            return (Criteria) this;
        }

        public Criteria andInstrStatusGreaterThanOrEqualTo(String value) {
            addCriterion("INSTR_STATUS >=", value, "instrStatus");
            return (Criteria) this;
        }

        public Criteria andInstrStatusLessThan(String value) {
            addCriterion("INSTR_STATUS <", value, "instrStatus");
            return (Criteria) this;
        }

        public Criteria andInstrStatusLessThanOrEqualTo(String value) {
            addCriterion("INSTR_STATUS <=", value, "instrStatus");
            return (Criteria) this;
        }

        public Criteria andInstrStatusLike(String value) {
            addCriterion("INSTR_STATUS like", value, "instrStatus");
            return (Criteria) this;
        }

        public Criteria andInstrStatusNotLike(String value) {
            addCriterion("INSTR_STATUS not like", value, "instrStatus");
            return (Criteria) this;
        }

        public Criteria andInstrStatusIn(List<String> values) {
            addCriterion("INSTR_STATUS in", values, "instrStatus");
            return (Criteria) this;
        }

        public Criteria andInstrStatusNotIn(List<String> values) {
            addCriterion("INSTR_STATUS not in", values, "instrStatus");
            return (Criteria) this;
        }

        public Criteria andInstrStatusBetween(String value1, String value2) {
            addCriterion("INSTR_STATUS between", value1, value2, "instrStatus");
            return (Criteria) this;
        }

        public Criteria andInstrStatusNotBetween(String value1, String value2) {
            addCriterion("INSTR_STATUS not between", value1, value2, "instrStatus");
            return (Criteria) this;
        }

        public Criteria andCCompanyauditflagIsNull() {
            addCriterion("C_COMPANYAUDITFLAG is null");
            return (Criteria) this;
        }

        public Criteria andCCompanyauditflagIsNotNull() {
            addCriterion("C_COMPANYAUDITFLAG is not null");
            return (Criteria) this;
        }

        public Criteria andCCompanyauditflagEqualTo(String value) {
            addCriterion("C_COMPANYAUDITFLAG =", value, "cCompanyauditflag");
            return (Criteria) this;
        }

        public Criteria andCCompanyauditflagNotEqualTo(String value) {
            addCriterion("C_COMPANYAUDITFLAG <>", value, "cCompanyauditflag");
            return (Criteria) this;
        }

        public Criteria andCCompanyauditflagGreaterThan(String value) {
            addCriterion("C_COMPANYAUDITFLAG >", value, "cCompanyauditflag");
            return (Criteria) this;
        }

        public Criteria andCCompanyauditflagGreaterThanOrEqualTo(String value) {
            addCriterion("C_COMPANYAUDITFLAG >=", value, "cCompanyauditflag");
            return (Criteria) this;
        }

        public Criteria andCCompanyauditflagLessThan(String value) {
            addCriterion("C_COMPANYAUDITFLAG <", value, "cCompanyauditflag");
            return (Criteria) this;
        }

        public Criteria andCCompanyauditflagLessThanOrEqualTo(String value) {
            addCriterion("C_COMPANYAUDITFLAG <=", value, "cCompanyauditflag");
            return (Criteria) this;
        }

        public Criteria andCCompanyauditflagLike(String value) {
            addCriterion("C_COMPANYAUDITFLAG like", value, "cCompanyauditflag");
            return (Criteria) this;
        }

        public Criteria andCCompanyauditflagNotLike(String value) {
            addCriterion("C_COMPANYAUDITFLAG not like", value, "cCompanyauditflag");
            return (Criteria) this;
        }

        public Criteria andCCompanyauditflagIn(List<String> values) {
            addCriterion("C_COMPANYAUDITFLAG in", values, "cCompanyauditflag");
            return (Criteria) this;
        }

        public Criteria andCCompanyauditflagNotIn(List<String> values) {
            addCriterion("C_COMPANYAUDITFLAG not in", values, "cCompanyauditflag");
            return (Criteria) this;
        }

        public Criteria andCCompanyauditflagBetween(String value1, String value2) {
            addCriterion("C_COMPANYAUDITFLAG between", value1, value2, "cCompanyauditflag");
            return (Criteria) this;
        }

        public Criteria andCCompanyauditflagNotBetween(String value1, String value2) {
            addCriterion("C_COMPANYAUDITFLAG not between", value1, value2, "cCompanyauditflag");
            return (Criteria) this;
        }

        public Criteria andVcOrioccurdateIsNull() {
            addCriterion("VC_ORIOCCURDATE is null");
            return (Criteria) this;
        }

        public Criteria andVcOrioccurdateIsNotNull() {
            addCriterion("VC_ORIOCCURDATE is not null");
            return (Criteria) this;
        }

        public Criteria andVcOrioccurdateEqualTo(String value) {
            addCriterion("VC_ORIOCCURDATE =", value, "vcOrioccurdate");
            return (Criteria) this;
        }

        public Criteria andVcOrioccurdateNotEqualTo(String value) {
            addCriterion("VC_ORIOCCURDATE <>", value, "vcOrioccurdate");
            return (Criteria) this;
        }

        public Criteria andVcOrioccurdateGreaterThan(String value) {
            addCriterion("VC_ORIOCCURDATE >", value, "vcOrioccurdate");
            return (Criteria) this;
        }

        public Criteria andVcOrioccurdateGreaterThanOrEqualTo(String value) {
            addCriterion("VC_ORIOCCURDATE >=", value, "vcOrioccurdate");
            return (Criteria) this;
        }

        public Criteria andVcOrioccurdateLessThan(String value) {
            addCriterion("VC_ORIOCCURDATE <", value, "vcOrioccurdate");
            return (Criteria) this;
        }

        public Criteria andVcOrioccurdateLessThanOrEqualTo(String value) {
            addCriterion("VC_ORIOCCURDATE <=", value, "vcOrioccurdate");
            return (Criteria) this;
        }

        public Criteria andVcOrioccurdateLike(String value) {
            addCriterion("VC_ORIOCCURDATE like", value, "vcOrioccurdate");
            return (Criteria) this;
        }

        public Criteria andVcOrioccurdateNotLike(String value) {
            addCriterion("VC_ORIOCCURDATE not like", value, "vcOrioccurdate");
            return (Criteria) this;
        }

        public Criteria andVcOrioccurdateIn(List<String> values) {
            addCriterion("VC_ORIOCCURDATE in", values, "vcOrioccurdate");
            return (Criteria) this;
        }

        public Criteria andVcOrioccurdateNotIn(List<String> values) {
            addCriterion("VC_ORIOCCURDATE not in", values, "vcOrioccurdate");
            return (Criteria) this;
        }

        public Criteria andVcOrioccurdateBetween(String value1, String value2) {
            addCriterion("VC_ORIOCCURDATE between", value1, value2, "vcOrioccurdate");
            return (Criteria) this;
        }

        public Criteria andVcOrioccurdateNotBetween(String value1, String value2) {
            addCriterion("VC_ORIOCCURDATE not between", value1, value2, "vcOrioccurdate");
            return (Criteria) this;
        }

        public Criteria andSettleInProvinceNoIsNull() {
            addCriterion("SETTLE_IN_PROVINCE_NO is null");
            return (Criteria) this;
        }

        public Criteria andSettleInProvinceNoIsNotNull() {
            addCriterion("SETTLE_IN_PROVINCE_NO is not null");
            return (Criteria) this;
        }

        public Criteria andSettleInProvinceNoEqualTo(String value) {
            addCriterion("SETTLE_IN_PROVINCE_NO =", value, "settleInProvinceNo");
            return (Criteria) this;
        }

        public Criteria andSettleInProvinceNoNotEqualTo(String value) {
            addCriterion("SETTLE_IN_PROVINCE_NO <>", value, "settleInProvinceNo");
            return (Criteria) this;
        }

        public Criteria andSettleInProvinceNoGreaterThan(String value) {
            addCriterion("SETTLE_IN_PROVINCE_NO >", value, "settleInProvinceNo");
            return (Criteria) this;
        }

        public Criteria andSettleInProvinceNoGreaterThanOrEqualTo(String value) {
            addCriterion("SETTLE_IN_PROVINCE_NO >=", value, "settleInProvinceNo");
            return (Criteria) this;
        }

        public Criteria andSettleInProvinceNoLessThan(String value) {
            addCriterion("SETTLE_IN_PROVINCE_NO <", value, "settleInProvinceNo");
            return (Criteria) this;
        }

        public Criteria andSettleInProvinceNoLessThanOrEqualTo(String value) {
            addCriterion("SETTLE_IN_PROVINCE_NO <=", value, "settleInProvinceNo");
            return (Criteria) this;
        }

        public Criteria andSettleInProvinceNoLike(String value) {
            addCriterion("SETTLE_IN_PROVINCE_NO like", value, "settleInProvinceNo");
            return (Criteria) this;
        }

        public Criteria andSettleInProvinceNoNotLike(String value) {
            addCriterion("SETTLE_IN_PROVINCE_NO not like", value, "settleInProvinceNo");
            return (Criteria) this;
        }

        public Criteria andSettleInProvinceNoIn(List<String> values) {
            addCriterion("SETTLE_IN_PROVINCE_NO in", values, "settleInProvinceNo");
            return (Criteria) this;
        }

        public Criteria andSettleInProvinceNoNotIn(List<String> values) {
            addCriterion("SETTLE_IN_PROVINCE_NO not in", values, "settleInProvinceNo");
            return (Criteria) this;
        }

        public Criteria andSettleInProvinceNoBetween(String value1, String value2) {
            addCriterion("SETTLE_IN_PROVINCE_NO between", value1, value2, "settleInProvinceNo");
            return (Criteria) this;
        }

        public Criteria andSettleInProvinceNoNotBetween(String value1, String value2) {
            addCriterion("SETTLE_IN_PROVINCE_NO not between", value1, value2, "settleInProvinceNo");
            return (Criteria) this;
        }

        public Criteria andSettleInCityNoIsNull() {
            addCriterion("SETTLE_IN_CITY_NO is null");
            return (Criteria) this;
        }

        public Criteria andSettleInCityNoIsNotNull() {
            addCriterion("SETTLE_IN_CITY_NO is not null");
            return (Criteria) this;
        }

        public Criteria andSettleInCityNoEqualTo(String value) {
            addCriterion("SETTLE_IN_CITY_NO =", value, "settleInCityNo");
            return (Criteria) this;
        }

        public Criteria andSettleInCityNoNotEqualTo(String value) {
            addCriterion("SETTLE_IN_CITY_NO <>", value, "settleInCityNo");
            return (Criteria) this;
        }

        public Criteria andSettleInCityNoGreaterThan(String value) {
            addCriterion("SETTLE_IN_CITY_NO >", value, "settleInCityNo");
            return (Criteria) this;
        }

        public Criteria andSettleInCityNoGreaterThanOrEqualTo(String value) {
            addCriterion("SETTLE_IN_CITY_NO >=", value, "settleInCityNo");
            return (Criteria) this;
        }

        public Criteria andSettleInCityNoLessThan(String value) {
            addCriterion("SETTLE_IN_CITY_NO <", value, "settleInCityNo");
            return (Criteria) this;
        }

        public Criteria andSettleInCityNoLessThanOrEqualTo(String value) {
            addCriterion("SETTLE_IN_CITY_NO <=", value, "settleInCityNo");
            return (Criteria) this;
        }

        public Criteria andSettleInCityNoLike(String value) {
            addCriterion("SETTLE_IN_CITY_NO like", value, "settleInCityNo");
            return (Criteria) this;
        }

        public Criteria andSettleInCityNoNotLike(String value) {
            addCriterion("SETTLE_IN_CITY_NO not like", value, "settleInCityNo");
            return (Criteria) this;
        }

        public Criteria andSettleInCityNoIn(List<String> values) {
            addCriterion("SETTLE_IN_CITY_NO in", values, "settleInCityNo");
            return (Criteria) this;
        }

        public Criteria andSettleInCityNoNotIn(List<String> values) {
            addCriterion("SETTLE_IN_CITY_NO not in", values, "settleInCityNo");
            return (Criteria) this;
        }

        public Criteria andSettleInCityNoBetween(String value1, String value2) {
            addCriterion("SETTLE_IN_CITY_NO between", value1, value2, "settleInCityNo");
            return (Criteria) this;
        }

        public Criteria andSettleInCityNoNotBetween(String value1, String value2) {
            addCriterion("SETTLE_IN_CITY_NO not between", value1, value2, "settleInCityNo");
            return (Criteria) this;
        }

        public Criteria andSettleTransferResultIsNull() {
            addCriterion("SETTLE_TRANSFER_RESULT is null");
            return (Criteria) this;
        }

        public Criteria andSettleTransferResultIsNotNull() {
            addCriterion("SETTLE_TRANSFER_RESULT is not null");
            return (Criteria) this;
        }

        public Criteria andSettleTransferResultEqualTo(String value) {
            addCriterion("SETTLE_TRANSFER_RESULT =", value, "settleTransferResult");
            return (Criteria) this;
        }

        public Criteria andSettleTransferResultNotEqualTo(String value) {
            addCriterion("SETTLE_TRANSFER_RESULT <>", value, "settleTransferResult");
            return (Criteria) this;
        }

        public Criteria andSettleTransferResultGreaterThan(String value) {
            addCriterion("SETTLE_TRANSFER_RESULT >", value, "settleTransferResult");
            return (Criteria) this;
        }

        public Criteria andSettleTransferResultGreaterThanOrEqualTo(String value) {
            addCriterion("SETTLE_TRANSFER_RESULT >=", value, "settleTransferResult");
            return (Criteria) this;
        }

        public Criteria andSettleTransferResultLessThan(String value) {
            addCriterion("SETTLE_TRANSFER_RESULT <", value, "settleTransferResult");
            return (Criteria) this;
        }

        public Criteria andSettleTransferResultLessThanOrEqualTo(String value) {
            addCriterion("SETTLE_TRANSFER_RESULT <=", value, "settleTransferResult");
            return (Criteria) this;
        }

        public Criteria andSettleTransferResultLike(String value) {
            addCriterion("SETTLE_TRANSFER_RESULT like", value, "settleTransferResult");
            return (Criteria) this;
        }

        public Criteria andSettleTransferResultNotLike(String value) {
            addCriterion("SETTLE_TRANSFER_RESULT not like", value, "settleTransferResult");
            return (Criteria) this;
        }

        public Criteria andSettleTransferResultIn(List<String> values) {
            addCriterion("SETTLE_TRANSFER_RESULT in", values, "settleTransferResult");
            return (Criteria) this;
        }

        public Criteria andSettleTransferResultNotIn(List<String> values) {
            addCriterion("SETTLE_TRANSFER_RESULT not in", values, "settleTransferResult");
            return (Criteria) this;
        }

        public Criteria andSettleTransferResultBetween(String value1, String value2) {
            addCriterion("SETTLE_TRANSFER_RESULT between", value1, value2, "settleTransferResult");
            return (Criteria) this;
        }

        public Criteria andSettleTransferResultNotBetween(String value1, String value2) {
            addCriterion("SETTLE_TRANSFER_RESULT not between", value1, value2, "settleTransferResult");
            return (Criteria) this;
        }

        public Criteria andSyncIsNull() {
            addCriterion("SYNC is null");
            return (Criteria) this;
        }

        public Criteria andSyncIsNotNull() {
            addCriterion("SYNC is not null");
            return (Criteria) this;
        }

        public Criteria andSyncEqualTo(String value) {
            addCriterion("SYNC =", value, "sync");
            return (Criteria) this;
        }

        public Criteria andSyncNotEqualTo(String value) {
            addCriterion("SYNC <>", value, "sync");
            return (Criteria) this;
        }

        public Criteria andSyncGreaterThan(String value) {
            addCriterion("SYNC >", value, "sync");
            return (Criteria) this;
        }

        public Criteria andSyncGreaterThanOrEqualTo(String value) {
            addCriterion("SYNC >=", value, "sync");
            return (Criteria) this;
        }

        public Criteria andSyncLessThan(String value) {
            addCriterion("SYNC <", value, "sync");
            return (Criteria) this;
        }

        public Criteria andSyncLessThanOrEqualTo(String value) {
            addCriterion("SYNC <=", value, "sync");
            return (Criteria) this;
        }

        public Criteria andSyncLike(String value) {
            addCriterion("SYNC like", value, "sync");
            return (Criteria) this;
        }

        public Criteria andSyncNotLike(String value) {
            addCriterion("SYNC not like", value, "sync");
            return (Criteria) this;
        }

        public Criteria andSyncIn(List<String> values) {
            addCriterion("SYNC in", values, "sync");
            return (Criteria) this;
        }

        public Criteria andSyncNotIn(List<String> values) {
            addCriterion("SYNC not in", values, "sync");
            return (Criteria) this;
        }

        public Criteria andSyncBetween(String value1, String value2) {
            addCriterion("SYNC between", value1, value2, "sync");
            return (Criteria) this;
        }

        public Criteria andSyncNotBetween(String value1, String value2) {
            addCriterion("SYNC not between", value1, value2, "sync");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNull() {
            addCriterion("CREATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIsNotNull() {
            addCriterion("CREATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andCreateTimeEqualTo(Date value) {
            addCriterion("CREATE_TIME =", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotEqualTo(Date value) {
            addCriterion("CREATE_TIME <>", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThan(Date value) {
            addCriterion("CREATE_TIME >", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("CREATE_TIME >=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThan(Date value) {
            addCriterion("CREATE_TIME <", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeLessThanOrEqualTo(Date value) {
            addCriterion("CREATE_TIME <=", value, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeIn(List<Date> values) {
            addCriterion("CREATE_TIME in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotIn(List<Date> values) {
            addCriterion("CREATE_TIME not in", values, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeBetween(Date value1, Date value2) {
            addCriterion("CREATE_TIME between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andCreateTimeNotBetween(Date value1, Date value2) {
            addCriterion("CREATE_TIME not between", value1, value2, "createTime");
            return (Criteria) this;
        }

        public Criteria andOpdateTimeIsNull() {
            addCriterion("OPDATE_TIME is null");
            return (Criteria) this;
        }

        public Criteria andOpdateTimeIsNotNull() {
            addCriterion("OPDATE_TIME is not null");
            return (Criteria) this;
        }

        public Criteria andOpdateTimeEqualTo(Date value) {
            addCriterion("OPDATE_TIME =", value, "opdateTime");
            return (Criteria) this;
        }

        public Criteria andOpdateTimeNotEqualTo(Date value) {
            addCriterion("OPDATE_TIME <>", value, "opdateTime");
            return (Criteria) this;
        }

        public Criteria andOpdateTimeGreaterThan(Date value) {
            addCriterion("OPDATE_TIME >", value, "opdateTime");
            return (Criteria) this;
        }

        public Criteria andOpdateTimeGreaterThanOrEqualTo(Date value) {
            addCriterion("OPDATE_TIME >=", value, "opdateTime");
            return (Criteria) this;
        }

        public Criteria andOpdateTimeLessThan(Date value) {
            addCriterion("OPDATE_TIME <", value, "opdateTime");
            return (Criteria) this;
        }

        public Criteria andOpdateTimeLessThanOrEqualTo(Date value) {
            addCriterion("OPDATE_TIME <=", value, "opdateTime");
            return (Criteria) this;
        }

        public Criteria andOpdateTimeIn(List<Date> values) {
            addCriterion("OPDATE_TIME in", values, "opdateTime");
            return (Criteria) this;
        }

        public Criteria andOpdateTimeNotIn(List<Date> values) {
            addCriterion("OPDATE_TIME not in", values, "opdateTime");
            return (Criteria) this;
        }

        public Criteria andOpdateTimeBetween(Date value1, Date value2) {
            addCriterion("OPDATE_TIME between", value1, value2, "opdateTime");
            return (Criteria) this;
        }

        public Criteria andOpdateTimeNotBetween(Date value1, Date value2) {
            addCriterion("OPDATE_TIME not between", value1, value2, "opdateTime");
            return (Criteria) this;
        }

        public Criteria andSeqidLikeInsensitive(String value) {
            addCriterion("upper(SEQID) like", value.toUpperCase(), "seqid");
            return (Criteria) this;
        }

        public Criteria andInstrNameLikeInsensitive(String value) {
            addCriterion("upper(INSTR_NAME) like", value.toUpperCase(), "instrName");
            return (Criteria) this;
        }

        public Criteria andInstrHklbLikeInsensitive(String value) {
            addCriterion("upper(INSTR_HKLB) like", value.toUpperCase(), "instrHklb");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankCodeLikeInsensitive(String value) {
            addCriterion("upper(SETTLE_OUT_BANK_CODE) like", value.toUpperCase(), "settleOutBankCode");
            return (Criteria) this;
        }

        public Criteria andSettleOutBankAccLikeInsensitive(String value) {
            addCriterion("upper(SETTLE_OUT_BANK_ACC) like", value.toUpperCase(), "settleOutBankAcc");
            return (Criteria) this;
        }

        public Criteria andSettleOutAccNameLikeInsensitive(String value) {
            addCriterion("upper(SETTLE_OUT_ACC_NAME) like", value.toUpperCase(), "settleOutAccName");
            return (Criteria) this;
        }

        public Criteria andSettleOutOpenBankLikeInsensitive(String value) {
            addCriterion("upper(SETTLE_OUT_OPEN_BANK) like", value.toUpperCase(), "settleOutOpenBank");
            return (Criteria) this;
        }

        public Criteria andSettleInBankCodeLikeInsensitive(String value) {
            addCriterion("upper(SETTLE_IN_BANK_CODE) like", value.toUpperCase(), "settleInBankCode");
            return (Criteria) this;
        }

        public Criteria andSettleInBankAccLikeInsensitive(String value) {
            addCriterion("upper(SETTLE_IN_BANK_ACC) like", value.toUpperCase(), "settleInBankAcc");
            return (Criteria) this;
        }

        public Criteria andSettleInAccNameLikeInsensitive(String value) {
            addCriterion("upper(SETTLE_IN_ACC_NAME) like", value.toUpperCase(), "settleInAccName");
            return (Criteria) this;
        }

        public Criteria andSettleInOpenBankLikeInsensitive(String value) {
            addCriterion("upper(SETTLE_IN_OPEN_BANK) like", value.toUpperCase(), "settleInOpenBank");
            return (Criteria) this;
        }

        public Criteria andSettleInCnapsNoLikeInsensitive(String value) {
            addCriterion("upper(SETTLE_IN_CNAPS_NO) like", value.toUpperCase(), "settleInCnapsNo");
            return (Criteria) this;
        }

        public Criteria andSettleDateLikeInsensitive(String value) {
            addCriterion("upper(SETTLE_DATE) like", value.toUpperCase(), "settleDate");
            return (Criteria) this;
        }

        public Criteria andFtNoteLikeInsensitive(String value) {
            addCriterion("upper(FT_NOTE) like", value.toUpperCase(), "ftNote");
            return (Criteria) this;
        }

        public Criteria andManagerLikeInsensitive(String value) {
            addCriterion("upper(MANAGER) like", value.toUpperCase(), "manager");
            return (Criteria) this;
        }

        public Criteria andProductCodeLikeInsensitive(String value) {
            addCriterion("upper(PRODUCT_CODE) like", value.toUpperCase(), "productCode");
            return (Criteria) this;
        }

        public Criteria andInstrStatusLikeInsensitive(String value) {
            addCriterion("upper(INSTR_STATUS) like", value.toUpperCase(), "instrStatus");
            return (Criteria) this;
        }

        public Criteria andCCompanyauditflagLikeInsensitive(String value) {
            addCriterion("upper(C_COMPANYAUDITFLAG) like", value.toUpperCase(), "cCompanyauditflag");
            return (Criteria) this;
        }

        public Criteria andVcOrioccurdateLikeInsensitive(String value) {
            addCriterion("upper(VC_ORIOCCURDATE) like", value.toUpperCase(), "vcOrioccurdate");
            return (Criteria) this;
        }

        public Criteria andSettleInProvinceNoLikeInsensitive(String value) {
            addCriterion("upper(SETTLE_IN_PROVINCE_NO) like", value.toUpperCase(), "settleInProvinceNo");
            return (Criteria) this;
        }

        public Criteria andSettleInCityNoLikeInsensitive(String value) {
            addCriterion("upper(SETTLE_IN_CITY_NO) like", value.toUpperCase(), "settleInCityNo");
            return (Criteria) this;
        }

        public Criteria andSettleTransferResultLikeInsensitive(String value) {
            addCriterion("upper(SETTLE_TRANSFER_RESULT) like", value.toUpperCase(), "settleTransferResult");
            return (Criteria) this;
        }

        public Criteria andSyncLikeInsensitive(String value) {
            addCriterion("upper(SYNC) like", value.toUpperCase(), "sync");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {
        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}