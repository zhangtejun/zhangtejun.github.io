/*
 *    Copyright 2006-2020 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.generator.codegen.mybatis3.javamapper;

import org.mybatis.generator.api.*;
import org.mybatis.generator.api.dom.java.*;
import org.mybatis.generator.codegen.AbstractJavaGenerator;
import org.mybatis.generator.codegen.RootClassInfo;
import org.mybatis.generator.config.Context;
import org.mybatis.generator.internal.util.JavaBeansUtil;

import java.util.ArrayList;
import java.util.List;

import static org.mybatis.generator.internal.util.JavaBeansUtil.getJavaBeansGetter;
import static org.mybatis.generator.internal.util.messages.Messages.getString;

public class JavaControllerGenerator extends AbstractJavaGenerator {

    private String requestMappingName;

    private String serviceName;

    public JavaControllerGenerator(String project) {
        super(project);
    }


    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getRequestMappingName() {
        return requestMappingName;
    }

    public void setRequestMappingName(String requestMappingName) {
        this.requestMappingName = requestMappingName;
    }

    @Override
    public List<CompilationUnit> getCompilationUnits() {
        FullyQualifiedTable table = introspectedTable.getFullyQualifiedTable();

        progressCallback.startTask(getString(
                "Progress.8", table.toString())); //$NON-NLS-1$
        Plugin plugins = context.getPlugins();
        CommentGenerator commentGenerator = context.getCommentGenerator();

        FullyQualifiedJavaType type = new FullyQualifiedJavaType(introspectedTable.getControllerInterfaceType());
        FullyQualifiedJavaType serviceType = new FullyQualifiedJavaType(introspectedTable.getRules().calculateAllFieldsClass().getShortName()+"Service");

        requestMappingName = JavaBeansUtil.firstCharLowcase(table.getDomainObjectName());
        serviceName = JavaBeansUtil.firstCharLowcase(serviceType.getShortName());

        TopLevelClass topLevelClass = new TopLevelClass(type);
        topLevelClass.addAnnotation("@Slf4j");
        topLevelClass.addAnnotation("@Controller");
        topLevelClass.addAnnotation("@RequestMapping(\"" + "/pposProductGroup-test/ppos_product/v" +"\")");
        topLevelClass.addAnnotation("@Api(value = \"场外投资\",tags={\"场外投资\"})");
        topLevelClass.setVisibility(JavaVisibility.PUBLIC);
        commentGenerator.addJavaFileComment(topLevelClass);

        FullyQualifiedJavaType superClass = getSuperClass();

        if (superClass != null) {
            topLevelClass.addImportedType(superClass);
            //topLevelClass
            topLevelClass.setSuperClass(superClass);
        }
        commentGenerator.addModelClassComment(topLevelClass, introspectedTable);

        //topLevelClass.addImportedType(introspectedTable.getServiceInterfaceType());
        topLevelClass.addImportedType(new FullyQualifiedJavaType(context.getJavaServiceGeneratorConfiguration().getImplementationPackage()+"."+introspectedTable.getRules().calculateAllFieldsClass().getShortName())+"Service");//

        topLevelClass.addImportedType(new FullyQualifiedJavaType("org.springframework.stereotype.Controller"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("lombok.extern.slf4j.Slf4j"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("org.springframework.web.bind.annotation.RequestMapping"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("javax.servlet.http.HttpServletResponse"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("org.springframework.web.bind.annotation.ResponseBody"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("org.springframework.web.bind.annotation.RequestBody"));

        topLevelClass.addImportedType(new FullyQualifiedJavaType("org.springframework.beans.factory.annotation.Autowired;"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("org.springframework.web.multipart.*"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("io.swagger.annotations.*"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("org.springframework.validation.annotation.*"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("com.github.xiaoymin.knife4j.annotations.ApiOperationSupport"));

        FullyQualifiedJavaType parameterType = new FullyQualifiedJavaType("javax.servlet.http.HttpServletRequest");
        FullyQualifiedJavaType exceptionType = new FullyQualifiedJavaType("com.hundsun.qin.platform.core.exceptions.BizException");
        topLevelClass.addImportedType(parameterType);
        topLevelClass.addImportedType(exceptionType);
        topLevelClass.addImportedType(FullyQualifiedJavaType.getNewListInstance());
        topLevelClass.addImportedType(FullyQualifiedJavaType.getNewMapInstance());
        FullyQualifiedJavaType RpcResultDTOType = new FullyQualifiedJavaType("com.hundsun.jrescloud.rpc.result.RpcResultDTO");

        topLevelClass.addImportedType(RpcResultDTOType);


        Field fieldService = new Field(JavaBeansUtil.firstCharLowcase(serviceType.getShortName()),parameterType);
        // topLevelClass.addImportedType(serviceType);

        fieldService.setName(JavaBeansUtil.firstCharLowcase(serviceType.getShortName()));
        fieldService.setType(serviceType); //$NON-NLS-1$
        fieldService.setVisibility(JavaVisibility.PRIVATE);
        fieldService.addAnnotation("@Autowired");
        topLevelClass.addField(fieldService);



        // 实现类全路径
        String interfaceType = introspectedTable.getServiceInterfaceType();
        int i = interfaceType.lastIndexOf(".");
        String pk = interfaceType.substring(0,i);
        String su = interfaceType.substring(i+1);

        //
        String domainObjectName = introspectedTable.getFullyQualifiedTable().getDomainObjectName();
        FullyQualifiedJavaType http = new FullyQualifiedJavaType(pk + ".http.IDownload"+domainObjectName+"HttpService");

        Field httpService = new Field(JavaBeansUtil.firstCharLowcase(http.getShortName()),http);
        httpService.setName(JavaBeansUtil.firstCharLowcase(http.getShortName()));
        httpService.setType(http); //$NON-NLS-1$
        httpService.setVisibility(JavaVisibility.PRIVATE);
        httpService.addAnnotation("@Autowired");
        topLevelClass.addField(httpService);
        topLevelClass.addImportedType(http);

        listMethod(topLevelClass, RpcResultDTOType);
        getMethod(topLevelClass,RpcResultDTOType);
        deleteMethod(topLevelClass, RpcResultDTOType);
        saveMethod(topLevelClass, RpcResultDTOType);
        insertBatch(topLevelClass, RpcResultDTOType);
        updateMethod(topLevelClass, RpcResultDTOType);
        download(topLevelClass, RpcResultDTOType,http);

        if (introspectedTable.getRules().generateInsertBatch()) {

        }
        if (introspectedTable.isConstructorBased()) {
            addParameterizedConstructor(topLevelClass);

            if (!introspectedTable.isImmutable()) {
                addDefaultConstructor(topLevelClass);
            }
        }
        String rootClass = getRootClass();

        List<CompilationUnit> answer = new ArrayList<CompilationUnit>();
        if (context.getPlugins().modelBaseRecordClassGenerated(
                topLevelClass, introspectedTable)) {
            answer.add(topLevelClass);
        }
        answer.add(getSwagger());
        answer.add(getInputDTO());
        answer.add(getOutputDTO());
        return answer;
    }

    private CompilationUnit getOutputDTO() {
        String packageName = context.getJavaServiceGeneratorConfiguration().getTargetPackage();
        TopLevelClass topLevelClass = new TopLevelClass(new FullyQualifiedJavaType(packageName + ".api.bean."+introspectedTable.getRules().calculateAllFieldsClass().getShortName()+"OutputDTO"));
        topLevelClass.addAnnotation("@Data");
        topLevelClass.setVisibility(JavaVisibility.PUBLIC);
        topLevelClass.addImportedType(new FullyQualifiedJavaType("lombok.Data"));
        FullyQualifiedJavaType javaType = new FullyQualifiedJavaType("java.io.Serializable");
        topLevelClass.addSuperInterface(javaType);
        topLevelClass.addImportedType(javaType);

        return topLevelClass;
    }

    private CompilationUnit getSwagger() {
        String packageName = context.getJavaServiceGeneratorConfiguration().getTargetPackage();
        TopLevelClass topLevelClass = new TopLevelClass(new FullyQualifiedJavaType(packageName + ".config.SwaggerConfiguration"));
        topLevelClass.addAnnotation("@Configuration");
        topLevelClass.addAnnotation("@EnableSwagger2");
        topLevelClass.addAnnotation("@EnableKnife4j");
        topLevelClass.addAnnotation("@Import(BeanValidatorPluginsConfiguration.class)");
        topLevelClass.setVisibility(JavaVisibility.PUBLIC);

        topLevelClass.addImportedType(new FullyQualifiedJavaType("com.github.xiaoymin.knife4j.spring.annotations.EnableKnife4j"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("org.springframework.context.annotation.Bean"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("org.springframework.context.annotation.Configuration"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("org.springframework.context.annotation.Import"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("springfox.bean.validators.configuration.BeanValidatorPluginsConfiguration"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("springfox.documentation.builders.ApiInfoBuilder"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("springfox.documentation.builders.PathSelectors"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("springfox.documentation.builders.RequestHandlerSelectors"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("springfox.documentation.service.ApiInfo"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("springfox.documentation.service.Contact"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("springfox.documentation.spi.DocumentationType"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("springfox.documentation.spring.web.plugins.Docket"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("springfox.documentation.swagger2.annotations.EnableSwagger2"));





        Method method = new Method("defaultApi2");
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setReturnType(new FullyQualifiedJavaType("Docket"));
        method.addAnnotation("@Bean(value = \"defaultApi2\")");
        method.addBodyLine("Docket docket = new Docket(DocumentationType.SWAGGER_2).apiInfo(apiInfo())");
        method.addBodyLine(".groupName(\"场外投资\").select()");
        method.addBodyLine(".apis(RequestHandlerSelectors.basePackage(\""+packageName+".controller\")).paths(PathSelectors.any()).build();");
        method.addBodyLine("return docket;");
        topLevelClass.addMethod(method);



        Method method2 = new Method("apiInfo");
        method2.setVisibility(JavaVisibility.PRIVATE);
        method2.setReturnType(new FullyQualifiedJavaType("ApiInfo"));
        method2.addBodyLine("return new ApiInfoBuilder().title(\"RESTful APIs\").description(\"RESTful APIS\")");
        method2.addBodyLine(".termsOfServiceUrl(\"http://localhost:18081/\").contact(new Contact(\"xxx\", \"xx\", \"xxxxx\"))");
        method2.addBodyLine(".version(\"1.0\").build();");
        topLevelClass.addMethod(method2);


        return topLevelClass;
    }

    private CompilationUnit getInputDTO() {
        String packageName = context.getJavaServiceGeneratorConfiguration().getTargetPackage();
        TopLevelClass topLevelClass = new TopLevelClass(new FullyQualifiedJavaType(packageName + ".api.bean."+introspectedTable.getRules().calculateAllFieldsClass().getShortName()+"InputDTO"));
        topLevelClass.addAnnotation("@Data");
        topLevelClass.setVisibility(JavaVisibility.PUBLIC);
        topLevelClass.addImportedType(new FullyQualifiedJavaType("lombok.Data"));

        Field field = new Field("exportData",new FullyQualifiedJavaType("String"));
        field.setVisibility(JavaVisibility.PRIVATE);

        Field field1 = new Field("titleName",new FullyQualifiedJavaType("String"));
        field1.setVisibility(JavaVisibility.PRIVATE);

        topLevelClass.addField(field);
        topLevelClass.addField(field1);
        FullyQualifiedJavaType javaType = new FullyQualifiedJavaType("java.io.Serializable");
        topLevelClass.addSuperInterface(javaType);
        topLevelClass.addImportedType(javaType);
        return topLevelClass;
    }

    public void download(TopLevelClass topLevelClass, FullyQualifiedJavaType resultType, FullyQualifiedJavaType http){
        FullyQualifiedJavaType exceptionType = new FullyQualifiedJavaType("com.hundsun.qin.platform.core.exceptions.BizException");
        Method method = new Method("download");
        method.setVisibility(JavaVisibility.PUBLIC);
        method.addException(exceptionType);
        FullyQualifiedJavaType listType = new FullyQualifiedJavaType(context.getJavaServiceGeneratorConfiguration().getDtoDirectory()+ introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "InputDTO");

        FullyQualifiedJavaType request = new FullyQualifiedJavaType("com.hundsun.amc.model.RequestDTO");
        request.addTypeArgument(listType);
        Parameter parameter = new Parameter(request,"param");
        parameter.addAnnotation("@Validated");
        parameter.addAnnotation("@RequestBody");
        method.addParameter(parameter);
        topLevelClass.addImportedType(listType);


        FullyQualifiedJavaType javaType = new FullyQualifiedJavaType(" org.springframework.http.ResponseEntity");
        javaType.addTypeArgument(new FullyQualifiedJavaType("byte[]"));
        method.setReturnType(javaType);
        method.addAnnotation("@ApiOperation(value = \"列表导出\", httpMethod = \"POST\")");
        method.addAnnotation("@ApiOperationSupport(ignoreParameters = {\"ip\",\"authUserInfo\",\"isNeedPage\",\"operatorCode\",\"systemFlag\",\"tenantId\",\"userName\",\"userToken\"})");
        method.addAnnotation("@RequestMapping(\"/"+JavaBeansUtil.firstCharLowcase(introspectedTable.getRules().calculateAllFieldsClass().getShortName())+JavaBeansUtil.getFirstCharacterUppercase(method.getName())+"\")");
        method.addAnnotation("@ResponseBody");
        method.addBodyLine("return  "+ JavaBeansUtil.firstCharLowcase(http.getShortName()) +".download"+introspectedTable.getRules().calculateAllFieldsClass().getShortName()+"Http(param);");
        topLevelClass.addMethod(method);
        topLevelClass.addImportedType(javaType);
    }

    public void listMethod(TopLevelClass topLevelClass, FullyQualifiedJavaType resultType){
        FullyQualifiedJavaType exceptionType = new FullyQualifiedJavaType("com.hundsun.qin.platform.core.exceptions.BizException");
        Method method = new Method("list");
        method.setName("list");
        method.setVisibility(JavaVisibility.PUBLIC);
        method.addException(exceptionType);
        method.setReturnType(resultType);
        method.addAnnotation("@ApiOperationSupport(ignoreParameters = {\"ip\",\"authUserInfo\",\"isNeedPage\",\"operatorCode\",\"systemFlag\",\"tenantId\",\"userName\",\"userToken\"})");
        method.addAnnotation("@ApiOperation(value = \"列表查询\", httpMethod = \"POST\")");
        method.addAnnotation("@RequestMapping(\"/"+JavaBeansUtil.firstCharLowcase(introspectedTable.getRules().calculateAllFieldsClass().getShortName())+JavaBeansUtil.getFirstCharacterUppercase(method.getName())+"\")");
        method.addAnnotation("@ResponseBody");
        if(introspectedTable.getRules().generateListParamClass()){
            FullyQualifiedJavaType listType = new FullyQualifiedJavaType(context.getJavaServiceGeneratorConfiguration().getDtoDirectory()+ introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "InputDTO");

            FullyQualifiedJavaType request = new FullyQualifiedJavaType("com.hundsun.amc.model.RequestDTO");
            request.addTypeArgument(listType);
            Parameter parameter = new Parameter(request,"param");
            parameter.addAnnotation("@Validated");
            parameter.addAnnotation("@RequestBody");
            method.addParameter(parameter);
            topLevelClass.addImportedType(listType);
            method.addBodyLine("RpcResultDTO result = new RpcResultDTO("+ serviceName +".list(param.getParam(),param.getPageNo(),param.getPageSize()));");
        }else{
            method.addBodyLine("RpcResultDTO result = new RpcResultDTO("+ serviceName +".list());");
        }
        method.addBodyLine("return result;");
        topLevelClass.addMethod(method);
    }
    public void getMethod(TopLevelClass topLevelClass, FullyQualifiedJavaType resultType){
        FullyQualifiedJavaType exceptionType = new FullyQualifiedJavaType("com.hundsun.qin.platform.core.exceptions.BizException");
        Method method = new Method("get");
        method.setName("get");
        method.setVisibility(JavaVisibility.PUBLIC);
        method.addException(exceptionType);
        method.setReturnType(resultType);
        FullyQualifiedJavaType request = new FullyQualifiedJavaType("com.hundsun.amc.model.RequestDTO");
        request.addTypeArgument(FullyQualifiedJavaType.getStringInstance());
        Parameter parameter = new Parameter(request, "id");
        parameter.addAnnotation("@RequestBody");
        method.addParameter(parameter);
        method.addAnnotation("@ApiOperation(value = \"根据主键id查询某一条记录\", httpMethod = \"POST\")");
        method.addAnnotation("@RequestMapping(\"/"+JavaBeansUtil.firstCharLowcase(introspectedTable.getRules().calculateAllFieldsClass().getShortName())+JavaBeansUtil.getFirstCharacterUppercase(method.getName())+"\")");
        method.addAnnotation("@ResponseBody");
        method.addAnnotation("@ApiOperationSupport(ignoreParameters = {\"ip\",\"authUserInfo\",\"isNeedPage\",\"operatorCode\",\"systemFlag\",\"tenantId\",\"userName\",\"userToken\"})");
        method.addBodyLine("RpcResultDTO result = new RpcResultDTO("+ serviceName +".get(id.getParam()));");
        method.addBodyLine("return result;");
        topLevelClass.addMethod(method);
    }
    public void deleteMethod(TopLevelClass topLevelClass, FullyQualifiedJavaType resultType){
        FullyQualifiedJavaType exceptionType = new FullyQualifiedJavaType("com.hundsun.qin.platform.core.exceptions.BizException");
        Method method = new Method("delete");
        method.setName("delete");
        method.setVisibility(JavaVisibility.PUBLIC);
        method.addException(exceptionType);
        method.setReturnType(resultType);
        FullyQualifiedJavaType request = new FullyQualifiedJavaType("com.hundsun.amc.model.RequestDTO");
        request.addTypeArgument(FullyQualifiedJavaType.getStringInstance());
        Parameter parameter = new Parameter(request, "id");
        parameter.addAnnotation("@RequestBody");
        method.addParameter(parameter);
        method.addAnnotation("@ApiOperation(value = \"根据主键id删除某一条记录\", httpMethod = \"POST\")");
        method.addAnnotation("@RequestMapping(\"/"+JavaBeansUtil.firstCharLowcase(introspectedTable.getRules().calculateAllFieldsClass().getShortName())+JavaBeansUtil.getFirstCharacterUppercase(method.getName())+"\")");
        method.addAnnotation("@ResponseBody");
        method.addAnnotation("@ApiOperationSupport(ignoreParameters = {\"ip\",\"authUserInfo\",\"isNeedPage\",\"operatorCode\",\"systemFlag\",\"tenantId\",\"userName\",\"userToken\"})");
        method.addBodyLine(serviceName +".delete(id.getParam());");
        method.addBodyLine("return new RpcResultDTO();");
        topLevelClass.addMethod(method);
    }

    public void saveMethod(TopLevelClass topLevelClass, FullyQualifiedJavaType resultType){
        FullyQualifiedJavaType exceptionType = new FullyQualifiedJavaType("com.hundsun.qin.platform.core.exceptions.BizException");
        Method method = new Method("save");
        method.setVisibility(JavaVisibility.PUBLIC);
        method.addException(exceptionType);
        method.setReturnType(resultType);
        method.setName("save");
        FullyQualifiedJavaType listType = new FullyQualifiedJavaType(context.getJavaServiceGeneratorConfiguration().getDtoDirectory()+ introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "InputDTO");
        FullyQualifiedJavaType request = new FullyQualifiedJavaType("com.hundsun.amc.model.RequestDTO");
        request.addTypeArgument(listType);
        Parameter parameter = new Parameter(request,"param");
        parameter.addAnnotation("@Validated");
        parameter.addAnnotation("@RequestBody");
        method.addParameter(parameter);
        method.addAnnotation("@ApiOperation(value = \"新增记录\", httpMethod = \"POST\")");
        method.addAnnotation("@ApiOperationSupport(ignoreParameters = {\"ip\",\"authUserInfo\",\"isNeedPage\",\"operatorCode\",\"systemFlag\",\"tenantId\",\"userName\",\"userToken\"})");
        method.addAnnotation("@RequestMapping(\"/"+JavaBeansUtil.firstCharLowcase(introspectedTable.getRules().calculateAllFieldsClass().getShortName())+JavaBeansUtil.getFirstCharacterUppercase(method.getName())+"\")");
        method.addAnnotation("@ResponseBody");
        method.addBodyLine(serviceName +".save(param.getParam());");
        method.addBodyLine("return new RpcResultDTO();");
        topLevelClass.addMethod(method);
    }

    public void insertBatch(TopLevelClass topLevelClass, FullyQualifiedJavaType resultType){
        FullyQualifiedJavaType exceptionType = new FullyQualifiedJavaType("com.hundsun.qin.platform.core.exceptions.BizException");
        Method method = new Method("insertBatch");
        method.setVisibility(JavaVisibility.PUBLIC);
        method.addException(exceptionType);
        method.setReturnType(resultType);
        method.setName("insertBatch");
        FullyQualifiedJavaType listType = new FullyQualifiedJavaType(context.getJavaServiceGeneratorConfiguration().getDtoDirectory()+ introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "InputDTO");
        FullyQualifiedJavaType request = new FullyQualifiedJavaType("com.hundsun.amc.model.RequestDTO");
        FullyQualifiedJavaType listInstance = FullyQualifiedJavaType.getNewListInstance();
        listInstance.addTypeArgument(listType);
        request.addTypeArgument(listInstance);
        Parameter parameter = new Parameter(request,"param");
        parameter.addAnnotation("@Validated");
        parameter.addAnnotation("@RequestBody");
        method.addParameter(parameter);
        method.addAnnotation("@ApiOperation(value = \"批量新增\", httpMethod = \"POST\")");
        method.addAnnotation("@ApiOperationSupport(ignoreParameters = {\"ip\",\"authUserInfo\",\"isNeedPage\",\"operatorCode\",\"systemFlag\",\"tenantId\",\"userName\",\"userToken\"})");
        method.addAnnotation("@RequestMapping(\"/"+JavaBeansUtil.firstCharLowcase(introspectedTable.getRules().calculateAllFieldsClass().getShortName())+JavaBeansUtil.getFirstCharacterUppercase(method.getName())+"\")");
        method.addAnnotation("@ResponseBody");
        method.addBodyLine(serviceName +".insertBatch(param.getParam());");
        method.addBodyLine("return new RpcResultDTO();");
        topLevelClass.addMethod(method);
    }

    public void updateMethod(TopLevelClass topLevelClass, FullyQualifiedJavaType resultType){
        FullyQualifiedJavaType exceptionType = new FullyQualifiedJavaType("com.hundsun.qin.platform.core.exceptions.BizException");
        Method method = new Method("update");
        method.setVisibility(JavaVisibility.PUBLIC);
        method.addException(exceptionType);
        method.setName("update");
        method.setReturnType(resultType);
        FullyQualifiedJavaType listType = new FullyQualifiedJavaType(context.getJavaServiceGeneratorConfiguration().getDtoDirectory() + introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "InputDTO");
        FullyQualifiedJavaType request = new FullyQualifiedJavaType("com.hundsun.amc.model.RequestDTO");
        topLevelClass.addImportedType(request);
        request.addTypeArgument(listType);
        Parameter parameter = new Parameter(request,"param");
        parameter.addAnnotation("@Validated");
        parameter.addAnnotation("@RequestBody");
        method.addParameter(parameter);
        method.addAnnotation("@ApiOperation(value = \"根据主键id修改某一条记录\", httpMethod = \"POST\")");
        method.addAnnotation("@ApiOperationSupport(ignoreParameters = {\"ip\",\"authUserInfo\",\"isNeedPage\",\"operatorCode\",\"systemFlag\",\"tenantId\",\"userName\",\"userToken\"})");
        method.addAnnotation("@RequestMapping(\"/"+JavaBeansUtil.firstCharLowcase(introspectedTable.getRules().calculateAllFieldsClass().getShortName())+JavaBeansUtil.getFirstCharacterUppercase(method.getName())+"\")");
        method.addAnnotation("@ResponseBody");
        method.addBodyLine(serviceName +".update(param.getParam());");
        method.addBodyLine("return new RpcResultDTO();");
        topLevelClass.addMethod(method);
    }
    public static Field getJavaBeansField(IntrospectedColumn introspectedColumn,
                                          Context context,
                                          IntrospectedTable introspectedTable) {
        FullyQualifiedJavaType fqjt = introspectedColumn
                .getFullyQualifiedJavaType();
        String property = introspectedColumn.getJavaProperty();
        String remark = introspectedColumn.getRemarks();


        Field field = new Field(property,fqjt);
        field.setVisibility(JavaVisibility.PRIVATE);
        field.setType(fqjt);
        field.setName(property);

        context.getCommentGenerator().addFieldComment(field,
                introspectedTable, introspectedColumn);

        return field;
    }
    private FullyQualifiedJavaType getSuperClass() {
        FullyQualifiedJavaType superClass = null;
        /*introspectedTable*/
        String superClassStr = introspectedTable.getContext().getJavaControllerGeneratorConfiguration().getProperty("superClass");
        if (superClassStr!= null &&  !"".equals(superClassStr)) {
            superClass = new FullyQualifiedJavaType(superClassStr);
        } else {
            String rootClass = getRootClass();
            if (rootClass != null) {
                superClass = new FullyQualifiedJavaType(rootClass);
            } else {
                superClass = null;
            }
        }

        return superClass;
    }

    private boolean includePrimaryKeyColumns() {
        return !introspectedTable.getRules().generatePrimaryKeyClass()
                && introspectedTable.hasPrimaryKeyColumns();
    }

    private boolean includeBLOBColumns() {
        return !introspectedTable.getRules().generateRecordWithBLOBsClass()
                && introspectedTable.hasBLOBColumns();
    }

    private void addParameterizedConstructor(TopLevelClass topLevelClass) {
        Method method = new Method(topLevelClass.getType().getShortName());
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setConstructor(true);
        method.setName(topLevelClass.getType().getShortName());
        context.getCommentGenerator().addGeneralMethodComment(method, introspectedTable);

        List<IntrospectedColumn> constructorColumns =
                includeBLOBColumns() ? introspectedTable.getAllColumns() :
                        introspectedTable.getNonBLOBColumns();

        for (IntrospectedColumn introspectedColumn : constructorColumns) {
            method.addParameter(new Parameter(introspectedColumn.getFullyQualifiedJavaType(),
                    introspectedColumn.getJavaProperty()));
            topLevelClass.addImportedType(introspectedColumn.getFullyQualifiedJavaType());
        }

        StringBuilder sb = new StringBuilder();
        if (introspectedTable.getRules().generatePrimaryKeyClass()) {
            boolean comma = false;
            sb.append("super("); //$NON-NLS-1$
            for (IntrospectedColumn introspectedColumn : introspectedTable
                    .getPrimaryKeyColumns()) {
                if (comma) {
                    sb.append(", "); //$NON-NLS-1$
                } else {
                    comma = true;
                }
                sb.append(introspectedColumn.getJavaProperty());
            }
            sb.append(");"); //$NON-NLS-1$
            method.addBodyLine(sb.toString());
        }

        List<IntrospectedColumn> introspectedColumns = getColumnsInThisClass();

        for (IntrospectedColumn introspectedColumn : introspectedColumns) {
            sb.setLength(0);
            sb.append("this."); //$NON-NLS-1$
            sb.append(introspectedColumn.getJavaProperty());
            sb.append(" = "); //$NON-NLS-1$
            sb.append(introspectedColumn.getJavaProperty());
            sb.append(';');
            method.addBodyLine(sb.toString());
        }

        topLevelClass.addMethod(method);
    }

    private List<IntrospectedColumn> getColumnsInThisClass() {
        List<IntrospectedColumn> introspectedColumns;
        if (includePrimaryKeyColumns()) {
            if (includeBLOBColumns()) {
                introspectedColumns = introspectedTable.getAllColumns();
            } else {
                introspectedColumns = introspectedTable.getNonBLOBColumns();
            }
        } else {
            if (includeBLOBColumns()) {
                introspectedColumns = introspectedTable
                        .getNonPrimaryKeyColumns();
            } else {
                introspectedColumns = introspectedTable.getBaseColumns();
            }
        }

        return introspectedColumns;
    }
}
