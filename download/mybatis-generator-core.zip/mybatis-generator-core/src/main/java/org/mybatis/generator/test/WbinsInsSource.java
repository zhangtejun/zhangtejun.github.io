/*
 *    Copyright 2006-2020 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.generator.test;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class WbinsInsSource implements Serializable {
    private String seqid;

    private String instrName;

    private String instrHklb;

    private String settleOutBankCode;

    private String settleOutBankAcc;

    private String settleOutAccName;

    private String settleOutOpenBank;

    private String settleInBankCode;

    private String settleInBankAcc;

    private String settleInAccName;

    private String settleInOpenBank;

    private String settleInCnapsNo;

    private BigDecimal ftAmount;

    private String settleDate;

    private String ftNote;

    private String manager;

    private String productCode;

    private String instrStatus;

    private String cCompanyauditflag;

    private String vcOrioccurdate;

    private String settleInProvinceNo;

    private String settleInCityNo;

    private String settleTransferResult;

    private String sync;

    private Date createTime;

    private Date opdateTime;

    private static final long serialVersionUID = 1L;

    public String getSeqid() {
        return seqid;
    }

    public void setSeqid(String seqid) {
        this.seqid = seqid == null ? null : seqid.trim();
    }

    public String getInstrName() {
        return instrName;
    }

    public void setInstrName(String instrName) {
        this.instrName = instrName == null ? null : instrName.trim();
    }

    public String getInstrHklb() {
        return instrHklb;
    }

    public void setInstrHklb(String instrHklb) {
        this.instrHklb = instrHklb == null ? null : instrHklb.trim();
    }

    public String getSettleOutBankCode() {
        return settleOutBankCode;
    }

    public void setSettleOutBankCode(String settleOutBankCode) {
        this.settleOutBankCode = settleOutBankCode == null ? null : settleOutBankCode.trim();
    }

    public String getSettleOutBankAcc() {
        return settleOutBankAcc;
    }

    public void setSettleOutBankAcc(String settleOutBankAcc) {
        this.settleOutBankAcc = settleOutBankAcc == null ? null : settleOutBankAcc.trim();
    }

    public String getSettleOutAccName() {
        return settleOutAccName;
    }

    public void setSettleOutAccName(String settleOutAccName) {
        this.settleOutAccName = settleOutAccName == null ? null : settleOutAccName.trim();
    }

    public String getSettleOutOpenBank() {
        return settleOutOpenBank;
    }

    public void setSettleOutOpenBank(String settleOutOpenBank) {
        this.settleOutOpenBank = settleOutOpenBank == null ? null : settleOutOpenBank.trim();
    }

    public String getSettleInBankCode() {
        return settleInBankCode;
    }

    public void setSettleInBankCode(String settleInBankCode) {
        this.settleInBankCode = settleInBankCode == null ? null : settleInBankCode.trim();
    }

    public String getSettleInBankAcc() {
        return settleInBankAcc;
    }

    public void setSettleInBankAcc(String settleInBankAcc) {
        this.settleInBankAcc = settleInBankAcc == null ? null : settleInBankAcc.trim();
    }

    public String getSettleInAccName() {
        return settleInAccName;
    }

    public void setSettleInAccName(String settleInAccName) {
        this.settleInAccName = settleInAccName == null ? null : settleInAccName.trim();
    }

    public String getSettleInOpenBank() {
        return settleInOpenBank;
    }

    public void setSettleInOpenBank(String settleInOpenBank) {
        this.settleInOpenBank = settleInOpenBank == null ? null : settleInOpenBank.trim();
    }

    public String getSettleInCnapsNo() {
        return settleInCnapsNo;
    }

    public void setSettleInCnapsNo(String settleInCnapsNo) {
        this.settleInCnapsNo = settleInCnapsNo == null ? null : settleInCnapsNo.trim();
    }

    public BigDecimal getFtAmount() {
        return ftAmount;
    }

    public void setFtAmount(BigDecimal ftAmount) {
        this.ftAmount = ftAmount;
    }

    public String getSettleDate() {
        return settleDate;
    }

    public void setSettleDate(String settleDate) {
        this.settleDate = settleDate == null ? null : settleDate.trim();
    }

    public String getFtNote() {
        return ftNote;
    }

    public void setFtNote(String ftNote) {
        this.ftNote = ftNote == null ? null : ftNote.trim();
    }

    public String getManager() {
        return manager;
    }

    public void setManager(String manager) {
        this.manager = manager == null ? null : manager.trim();
    }

    public String getProductCode() {
        return productCode;
    }

    public void setProductCode(String productCode) {
        this.productCode = productCode == null ? null : productCode.trim();
    }

    public String getInstrStatus() {
        return instrStatus;
    }

    public void setInstrStatus(String instrStatus) {
        this.instrStatus = instrStatus == null ? null : instrStatus.trim();
    }

    public String getcCompanyauditflag() {
        return cCompanyauditflag;
    }

    public void setcCompanyauditflag(String cCompanyauditflag) {
        this.cCompanyauditflag = cCompanyauditflag == null ? null : cCompanyauditflag.trim();
    }

    public String getVcOrioccurdate() {
        return vcOrioccurdate;
    }

    public void setVcOrioccurdate(String vcOrioccurdate) {
        this.vcOrioccurdate = vcOrioccurdate == null ? null : vcOrioccurdate.trim();
    }

    public String getSettleInProvinceNo() {
        return settleInProvinceNo;
    }

    public void setSettleInProvinceNo(String settleInProvinceNo) {
        this.settleInProvinceNo = settleInProvinceNo == null ? null : settleInProvinceNo.trim();
    }

    public String getSettleInCityNo() {
        return settleInCityNo;
    }

    public void setSettleInCityNo(String settleInCityNo) {
        this.settleInCityNo = settleInCityNo == null ? null : settleInCityNo.trim();
    }

    public String getSettleTransferResult() {
        return settleTransferResult;
    }

    public void setSettleTransferResult(String settleTransferResult) {
        this.settleTransferResult = settleTransferResult == null ? null : settleTransferResult.trim();
    }

    public String getSync() {
        return sync;
    }

    public void setSync(String sync) {
        this.sync = sync == null ? null : sync.trim();
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Date getOpdateTime() {
        return opdateTime;
    }

    public void setOpdateTime(Date opdateTime) {
        this.opdateTime = opdateTime;
    }
}