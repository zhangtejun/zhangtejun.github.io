/*
 *    Copyright 2006-2020 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.generator.codegen.mybatis3.javamapper;


import org.mybatis.generator.api.*;
import org.mybatis.generator.api.dom.java.*;
import org.mybatis.generator.codegen.AbstractJavaGenerator;
import org.mybatis.generator.codegen.RootClassInfo;
import org.mybatis.generator.config.Context;
import org.mybatis.generator.internal.util.JavaBeansUtil;

import java.util.ArrayList;
import java.util.List;

import static org.mybatis.generator.internal.util.JavaBeansUtil.*;
import static org.mybatis.generator.internal.util.messages.Messages.getString;

public class JavaAtomImplGenerator extends AbstractJavaGenerator {

    public JavaAtomImplGenerator(String project) {
        super(project);
    }

    @Override
    public List<CompilationUnit> getCompilationUnits() {
        FullyQualifiedTable table = introspectedTable.getFullyQualifiedTable();
        progressCallback.startTask(getString(
                "Progress.8", table.toString())); //$NON-NLS-1$
        Plugin plugins = context.getPlugins();
        CommentGenerator commentGenerator = context.getCommentGenerator();


        // 实现类全路径
        String interfaceType = introspectedTable.getServiceInterfaceType();
        int i = interfaceType.lastIndexOf(".");
        String pk = interfaceType.substring(0,i);
        String su = interfaceType.substring(i+1);

        //
        String domainObjectName = introspectedTable.getFullyQualifiedTable().getDomainObjectName();


        FullyQualifiedJavaType type = new FullyQualifiedJavaType(pk + ".atom.impl."+domainObjectName+"AtomImpl");


        //FullyQualifiedJavaType type = new FullyQualifiedJavaType(introspectedTable.getServiceImplementationType());


        TopLevelClass topLevelClass = new TopLevelClass(type);
        topLevelClass.addAnnotation("@Slf4j");
        topLevelClass.addAnnotation("@Component");
        topLevelClass.setVisibility(JavaVisibility.PUBLIC);
        commentGenerator.addJavaFileComment(topLevelClass);

        // FullyQualifiedJavaType superClass = getSuperClass();

        FullyQualifiedJavaType superClass = new FullyQualifiedJavaType(pk + ".atom.I"+domainObjectName+"Atom");
        if (superClass != null) {
            //topLevelClass.setSuperClass(superClass);

            topLevelClass.addImportedType(superClass);
            //topLevelClass
            topLevelClass.addSuperInterface(superClass);
        }
        commentGenerator.addModelClassComment(topLevelClass, introspectedTable);

        List<IntrospectedColumn> introspectedColumns = getColumnsInThisClass();


        topLevelClass.addImportedType(introspectedTable.getMyBatis3JavaMapperType());
        topLevelClass.addImportedType(FullyQualifiedJavaType.getNewListInstance());
        topLevelClass.addImportedType(introspectedTable.getRules().calculateAllFieldsClass());//

        topLevelClass.addImportedType(new FullyQualifiedJavaType("org.springframework.beans.factory.annotation.Autowired"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("org.springframework.stereotype.Component"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("lombok.extern.slf4j.Slf4j"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("com.github.pagehelper.Page"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("org.springframework.beans.BeanUtils"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("com.hundsun.amc.utils.BeanMapUtils"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("com.hundsun.amc.support.OperCenterDictSupport"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType(context.getJavaServiceGeneratorConfiguration().getDtoDirectory() + introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "OutputDTO"));

        FullyQualifiedJavaType mapperType= new FullyQualifiedJavaType(introspectedTable.getMyBatis3JavaMapperType());
        Field field = new Field(JavaBeansUtil.firstCharLowcase(mapperType.getShortName()),mapperType);
        field.setName(JavaBeansUtil.firstCharLowcase(mapperType.getShortName())); //$NON-NLS-1$
        field.setType(mapperType); //$NON-NLS-1$
        field.setVisibility(JavaVisibility.PRIVATE);
        field.addAnnotation("@Autowired");

        topLevelClass.addField(field);

         // add
        FullyQualifiedJavaType dictSupport = new FullyQualifiedJavaType("OperCenterDictSupport");
        Field fieldO = new Field(JavaBeansUtil.firstCharLowcase(dictSupport.getShortName()),dictSupport);
        fieldO.setName(JavaBeansUtil.firstCharLowcase(dictSupport.getShortName())); //$NON-NLS-1$
        fieldO.setType(dictSupport); //$NON-NLS-1$
        fieldO.setVisibility(JavaVisibility.PRIVATE);
        fieldO.addAnnotation("@Autowired");

        topLevelClass.addField(fieldO);


        FullyQualifiedJavaType parameterType = FullyQualifiedJavaType.getNewListInstance();
        parameterType.addTypeArgument(introspectedTable.getRules().calculateAllFieldsClass());
        String methodName = introspectedTable.getInsertBatchStatementId();

        if (introspectedTable.getRules().generateInsertBatch()) {
            Method method = new Method(methodName);
            method.setVisibility(JavaVisibility.PUBLIC);
            method.addParameter(new Parameter(parameterType,"list"));
            method.setReturnType(FullyQualifiedJavaType.getIntInstance());

            method.setName(methodName); //$NON-NLS-1$
            method.addBodyLine("if(list != null && list.size() > 0 ){");
            method.addBodyLine("return "+ JavaBeansUtil.firstCharLowcase(mapperType.getShortName()) +"." + methodName +"(list);" ); //$NON-NLS-1$
            method.addBodyLine("}" ); //$NON-NLS-1$
            method.addBodyLine("return 0;" ); //$NON-NLS-1$

            commentGenerator.addGeneralMethodComment(method, introspectedTable);
            topLevelClass.addMethod(method);
        }
        if (introspectedTable.isConstructorBased()) {
            addParameterizedConstructor(topLevelClass);

            if (!introspectedTable.isImmutable()) {
                addDefaultConstructor(topLevelClass);
            }
        }
        addListMethod(topLevelClass);
        addGetMethod(topLevelClass);
        addSaveMethod(topLevelClass);
        addDeleteMethod(topLevelClass);
        addUpdateMethod(topLevelClass);
        String rootClass = getRootClass();
        List<CompilationUnit> answer = new ArrayList<CompilationUnit>();
        if (context.getPlugins().modelBaseRecordClassGenerated(
                topLevelClass, introspectedTable)) {
            answer.add(topLevelClass);
        }
        return answer;
    }
    public void addListMethod(TopLevelClass topLevelClass){
        FullyQualifiedJavaType mapperType= new FullyQualifiedJavaType(introspectedTable.getMyBatis3JavaMapperType());
        String mapperName = JavaBeansUtil.firstCharLowcase(mapperType.getShortName());
        Method method = new Method(mapperName);
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName("list");
        FullyQualifiedJavaType resultType = new FullyQualifiedJavaType("com.github.pagehelper.PageInfo");
        FullyQualifiedJavaType exampleType = new FullyQualifiedJavaType(introspectedTable.getExampleType());
        resultType.addTypeArgument(new FullyQualifiedJavaType(introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "OutputDTO"));
        topLevelClass.addImportedType(exampleType);
        method.setReturnType(resultType);
        topLevelClass.addImportedType(resultType);

        method.addBodyLine(exampleType.getShortName() +  " example "
                + "= new " + exampleType.getShortName() + "();");

        if(introspectedTable.getRules().generateListParamClass()){
            FullyQualifiedJavaType listType = new FullyQualifiedJavaType(context.getJavaServiceGeneratorConfiguration().getDtoDirectory()+ introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "InputDTO");
            Parameter parameter = new Parameter(listType,"param");
            topLevelClass.addImportedType(listType);
            topLevelClass.addImportedType(new FullyQualifiedJavaType("com.github.pagehelper.PageHelper"));
            //method.addParameter(parameter);
            method.addParameter(0,new Parameter(listType,"param"));
            method.addParameter(1,new Parameter(new FullyQualifiedJavaType("Integer"),"pageNo"));
            method.addParameter(2,new Parameter(new FullyQualifiedJavaType("Integer"),"pageSize"));

            method.addBodyLine("Page<"+introspectedTable.getRules().calculateAllFieldsClass().getShortName()+"> pageInfo = " +
                    "PageHelper.startPage(pageNo, pageSize,true);");
        }
        method.addBodyLine(mapperName + "." + introspectedTable.getSelectByExampleStatementId() +"(example);");
        method.addBodyLine("List<"+ introspectedTable.getRules().calculateAllFieldsClass().getShortName() +"> result = pageInfo.getResult();");

        method.addBodyLine("Page<"+introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "OutputDTO"+"> ret = new Page<>();");
        method.addBodyLine("BeanUtils.copyProperties(result,ret);");
        method.addBodyLine("Optional.ofNullable(result).orElse(new ArrayList<>()).forEach(it ->{");
        method.addBodyLine(""+introspectedTable.getRules().calculateAllFieldsClass().getShortName()+"OutputDTO dto = BeanMapUtils.copyPropertiesDeeply(it, "+introspectedTable.getRules().calculateAllFieldsClass().getShortName()+"OutputDTO.class);");
        method.addBodyLine("// ");
        method.addBodyLine("ret.add(dto);");
        method.addBodyLine("});");
        method.addBodyLine("return new PageInfo<>(ret);");
        topLevelClass.addMethod(method);
        topLevelClass.addImportedType("java.util.*");
    }


    public void addGetMethod(TopLevelClass topLevelClass){
        FullyQualifiedJavaType mapperType= new FullyQualifiedJavaType(introspectedTable.getMyBatis3JavaMapperType());
        String mapperName = JavaBeansUtil.firstCharLowcase(mapperType.getShortName());
        Method method = new Method("get");
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName("get");
        String out = introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "OutputDTO";
        method.setReturnType(new FullyQualifiedJavaType(out));
        method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(),"id"));
        method.addBodyLine(introspectedTable.getRules().calculateAllFieldsClass().getShortName() + " info = " + mapperName + "." + introspectedTable.getSelectByPrimaryKeyStatementId() +"(id);");
        method.addBodyLine("if (info == null){");
        method.addBodyLine("return new "+out+"();");
        method.addBodyLine("}");
        method.addBodyLine(introspectedTable.getRules().calculateAllFieldsClass().getShortName()+ "OutputDTO" + " outRet = BeanMapUtils.copyPropertiesDeeply(info,"+out+".class);");
        method.addBodyLine("return outRet;");
        topLevelClass.addMethod(method);
    }
    public void addSaveMethod(TopLevelClass topLevelClass){
        FullyQualifiedJavaType mapperType= new FullyQualifiedJavaType(introspectedTable.getMyBatis3JavaMapperType());
        String mapperName = JavaBeansUtil.firstCharLowcase(mapperType.getShortName());
        Method method = new Method("save");
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName("save");
        method.addParameter(new Parameter(introspectedTable.getRules().calculateAllFieldsClass(),"toDB"));
        method.addBodyLine(mapperName + "." + introspectedTable.getInsertSelectiveStatementId() +"(toDB);");
        topLevelClass.addMethod(method);
    }
    public void addDeleteMethod(TopLevelClass topLevelClass){
        FullyQualifiedJavaType mapperType= new FullyQualifiedJavaType(introspectedTable.getMyBatis3JavaMapperType());
        String mapperName = JavaBeansUtil.firstCharLowcase(mapperType.getShortName());
        Method method = new Method("delete");
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName("delete");
        method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(),"id"));
        method.addBodyLine(mapperName + "." + introspectedTable.getDeleteByPrimaryKeyStatementId() +"(id);");
        topLevelClass.addMethod(method);
    }

    public void addUpdateMethod(TopLevelClass topLevelClass){
        FullyQualifiedJavaType mapperType= new FullyQualifiedJavaType(introspectedTable.getMyBatis3JavaMapperType());
        String mapperName = JavaBeansUtil.firstCharLowcase(mapperType.getShortName());
        Method method = new Method("update");
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName("update");
        method.addParameter(new Parameter(introspectedTable.getRules().calculateAllFieldsClass(),"toDB"));
        method.addBodyLine(mapperName + "." + introspectedTable.getUpdateByPrimaryKeySelectiveStatementId() +"(toDB);");
        topLevelClass.addMethod(method);
    }
    private FullyQualifiedJavaType getSuperClass() {
        FullyQualifiedJavaType superClass = null;
        /*introspectedTable*/
        if (introspectedTable.getRules().generateJavaService()) {
            superClass = new FullyQualifiedJavaType(introspectedTable
                    .getServiceInterfaceType());
        } else {
            String rootClass = getRootClass();
            if (rootClass != null) {
                superClass = new FullyQualifiedJavaType(rootClass);
            } else {
                superClass = null;
            }
        }

        return superClass;
    }

    private boolean includePrimaryKeyColumns() {
        return !introspectedTable.getRules().generatePrimaryKeyClass()
                && introspectedTable.hasPrimaryKeyColumns();
    }

    private boolean includeBLOBColumns() {
        return !introspectedTable.getRules().generateRecordWithBLOBsClass()
                && introspectedTable.hasBLOBColumns();
    }

    private void addParameterizedConstructor(TopLevelClass topLevelClass) {
        Method method = new Method(topLevelClass.getType().getShortName());
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setConstructor(true);
        method.setName(topLevelClass.getType().getShortName());
        context.getCommentGenerator().addGeneralMethodComment(method, introspectedTable);

        List<IntrospectedColumn> constructorColumns =
                includeBLOBColumns() ? introspectedTable.getAllColumns() :
                        introspectedTable.getNonBLOBColumns();

        for (IntrospectedColumn introspectedColumn : constructorColumns) {
            method.addParameter(new Parameter(introspectedColumn.getFullyQualifiedJavaType(),
                    introspectedColumn.getJavaProperty()));
            topLevelClass.addImportedType(introspectedColumn.getFullyQualifiedJavaType());
        }

        StringBuilder sb = new StringBuilder();
        if (introspectedTable.getRules().generatePrimaryKeyClass()) {
            boolean comma = false;
            sb.append("super("); //$NON-NLS-1$
            for (IntrospectedColumn introspectedColumn : introspectedTable
                    .getPrimaryKeyColumns()) {
                if (comma) {
                    sb.append(", "); //$NON-NLS-1$
                } else {
                    comma = true;
                }
                sb.append(introspectedColumn.getJavaProperty());
            }
            sb.append(");"); //$NON-NLS-1$
            method.addBodyLine(sb.toString());
        }

        List<IntrospectedColumn> introspectedColumns = getColumnsInThisClass();

        for (IntrospectedColumn introspectedColumn : introspectedColumns) {
            sb.setLength(0);
            sb.append("this."); //$NON-NLS-1$
            sb.append(introspectedColumn.getJavaProperty());
            sb.append(" = "); //$NON-NLS-1$
            sb.append(introspectedColumn.getJavaProperty());
            sb.append(';');
            method.addBodyLine(sb.toString());
        }

        topLevelClass.addMethod(method);
    }

    private List<IntrospectedColumn> getColumnsInThisClass() {
        List<IntrospectedColumn> introspectedColumns;
        if (includePrimaryKeyColumns()) {
            if (includeBLOBColumns()) {
                introspectedColumns = introspectedTable.getAllColumns();
            } else {
                introspectedColumns = introspectedTable.getNonBLOBColumns();
            }
        } else {
            if (includeBLOBColumns()) {
                introspectedColumns = introspectedTable
                        .getNonPrimaryKeyColumns();
            } else {
                introspectedColumns = introspectedTable.getBaseColumns();
            }
        }

        return introspectedColumns;
    }
}
