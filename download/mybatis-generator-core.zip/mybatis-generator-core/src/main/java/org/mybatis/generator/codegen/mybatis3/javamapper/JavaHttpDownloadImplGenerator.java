/*
 *    Copyright 2006-2020 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.generator.codegen.mybatis3.javamapper;


import org.mybatis.generator.api.CommentGenerator;
import org.mybatis.generator.api.FullyQualifiedTable;
import org.mybatis.generator.api.IntrospectedColumn;
import org.mybatis.generator.api.Plugin;
import org.mybatis.generator.api.dom.java.*;
import org.mybatis.generator.codegen.AbstractJavaGenerator;
import org.mybatis.generator.config.JavaServiceGeneratorConfiguration;
import org.mybatis.generator.internal.util.JavaBeansUtil;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import static org.mybatis.generator.internal.util.messages.Messages.getString;

public class JavaHttpDownloadImplGenerator extends AbstractJavaGenerator {
    String serverApi;

    public void setServerApi(String serverApi) {
        this.serverApi = serverApi;
    }

    public JavaHttpDownloadImplGenerator(String project) {
        super(project);
    }

    @Override
    public List<CompilationUnit> getCompilationUnits() {
        FullyQualifiedTable table = introspectedTable.getFullyQualifiedTable();
        progressCallback.startTask(getString(
                "Progress.8", table.toString())); //$NON-NLS-1$
        Plugin plugins = context.getPlugins();
        CommentGenerator commentGenerator = context.getCommentGenerator();

        // FullyQualifiedJavaType type = new FullyQualifiedJavaType(introspectedTable.getServiceImplementationType());


        // 实现类全路径
        String interfaceType = introspectedTable.getServiceInterfaceType();
        int i = interfaceType.lastIndexOf(".");
        String pk = interfaceType.substring(0,i);
        String su = interfaceType.substring(i+1);

        //
        String domainObjectName = introspectedTable.getFullyQualifiedTable().getDomainObjectName();


        FullyQualifiedJavaType type = new FullyQualifiedJavaType(pk + ".http.impl.Download"+domainObjectName+"HttpServiceImpl");

        TopLevelClass topLevelClass = new TopLevelClass(type);
        topLevelClass.addAnnotation("@Service");
        // topLevelClass.addAnnotation("@Transactional");
        topLevelClass.setVisibility(JavaVisibility.PUBLIC);
        commentGenerator.addJavaFileComment(topLevelClass);

        FullyQualifiedJavaType superClass = getSuperClass();
        if (superClass != null) {
            //topLevelClass.setSuperClass(superClass);

            topLevelClass.addImportedType(superClass);
            //topLevelClass
            topLevelClass.addSuperInterface(superClass);
        }
        commentGenerator.addModelClassComment(topLevelClass, introspectedTable);

        List<IntrospectedColumn> introspectedColumns = getColumnsInThisClass();
        topLevelClass.addImportedType(new FullyQualifiedJavaType("org.springframework.beans.factory.annotation.Autowired"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("org.springframework.transaction.annotation.Transactional"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("org.springframework.stereotype.Service"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("org.springframework.util.Assert"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("org.springframework.http.*"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("java.io.*"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("org.apache.commons.lang3.StringUtils"));
        topLevelClass.addImportedType("com.github.pagehelper.PageInfo");
        topLevelClass.addImportedType("com.alibaba.fastjson.JSON");
        topLevelClass.addImportedType("java.util.*");
        topLevelClass.addImportedType("com.hundsun.amc.utils.*");
        topLevelClass.addImportedType("com.hundsun.jrescloud.common.exception.BaseBizException");
        topLevelClass.addImportedType("java.net.URLEncoder");

        // set OutputDTO
        FullyQualifiedJavaType type2 = new FullyQualifiedJavaType(context.getJavaServiceGeneratorConfiguration().getDtoDirectory() + introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "OutputDTO");
        topLevelClass.addImportedType(type2);

        FullyQualifiedJavaType mapperType= new FullyQualifiedJavaType("com.hundsun.amc.support.SysCacheSupport");
        Field field = new Field(JavaBeansUtil.firstCharLowcase("SysCacheSupport"),mapperType);
        field.setName(JavaBeansUtil.firstCharLowcase(mapperType.getShortName())); //$NON-NLS-1$
        field.setType(mapperType); //$NON-NLS-1$
        field.setVisibility(JavaVisibility.PRIVATE);
        field.addAnnotation("@Autowired");
        topLevelClass.addImportedType(mapperType);
        topLevelClass.addField(field);

        // 导入包 web 层的service
        topLevelClass.addImportedType(new FullyQualifiedJavaType(pk + ".service."+domainObjectName+"Service"));

        FullyQualifiedJavaType mapperType1 = new FullyQualifiedJavaType(domainObjectName+"Service");
        String serverApi = JavaBeansUtil.firstCharLowcase(mapperType1.getShortName());
        //
        setServerApi(serverApi);

        Field field1 = new Field(serverApi,mapperType1);
        field1.setName(serverApi); //$NON-NLS-1$
        field1.setType(mapperType1); //$NON-NLS-1$
        field1.setVisibility(JavaVisibility.PRIVATE);
        field1.addAnnotation("@Autowired");

        topLevelClass.addField(field1);


        FullyQualifiedJavaType parameterType = FullyQualifiedJavaType.getNewListInstance();
        parameterType.addTypeArgument(introspectedTable.getRules().calculateAllFieldsClass());

        if (introspectedTable.isConstructorBased()) {
            addParameterizedConstructor(topLevelClass);

            if (!introspectedTable.isImmutable()) {
                addDefaultConstructor(topLevelClass);
            }
        }
        addDownloadHttp(topLevelClass,serverApi);
        List<CompilationUnit> answer = new ArrayList<CompilationUnit>();
        if (context.getPlugins().modelBaseRecordClassGenerated(
                topLevelClass, introspectedTable)) {
            answer.add(topLevelClass);
        }
        return answer;
    }

    private void addDownloadHttp(TopLevelClass topLevelClass, String serverApi) {
        // 实现类全路径
        String interfaceType = introspectedTable.getServiceInterfaceType();
        int i = interfaceType.lastIndexOf(".");
        String pk = interfaceType.substring(0,i);
        //
        String domainObjectName = introspectedTable.getFullyQualifiedTable().getDomainObjectName();

        FullyQualifiedJavaType inType = new FullyQualifiedJavaType(pk + ".http.IDownload"+domainObjectName+"HttpService");

        Interface interfaze = JavaHttpDownloadGenerator.map.getOrDefault(inType.getShortName(),  new Interface(inType));
        topLevelClass.addImportedTypes(interfaze.getImportedTypes()); // 接口import
        interfaze.getMethods().forEach(e -> {
            Method method = new Method(e.getName());
            method.setVisibility(JavaVisibility.PUBLIC);
            e.getParameters().forEach(it -> method.addParameter(it));
            method.setReturnType(e.getReturnType().get());
            topLevelClass.addMethod(method);
            // method 增加 bodyLine
            method.addBodyLine("Assert.isTrue(inputParam!= null && inputParam.getParam() != null ,\""+e.getName()+" error inputParam is null\");");
            method.addBodyLine("Assert.isTrue(StringUtils.isNotBlank(inputParam.getParam().getExportData()) && StringUtils.isNotBlank(inputParam.getParam().getTitleName()) ,\""+e.getName()+" error titleName or exportdata is null\");");
            method.addBodyLine("String excelExportMaxLimit = sysCacheSupport.getParameter(\"ExcelExportMaxLimit\");");
            method.addBodyLine("if(StringUtils.isBlank(excelExportMaxLimit)){");
            method.addBodyLine("excelExportMaxLimit = \"10000\";");
            method.addBodyLine("}");
            method.addBodyLine("inputParam.setPageNo(1);");
            method.addBodyLine("inputParam.setPageSize(Integer.valueOf(excelExportMaxLimit));");
            method.addBodyLine("PageInfo<"+introspectedTable.getRules().calculateAllFieldsClass().getShortName()+"OutputDTO> infoList = "+serverApi+".list(inputParam.getParam(), inputParam.getPageNo(), inputParam.getPageSize());");
            method.addBodyLine("if(infoList.getTotal()==0){");
            method.addBodyLine("throw new BaseBizException(\"-1\",\"列表暂无数据\");");
            method.addBodyLine("}");
            method.addBodyLine("LinkedHashMap<String,String> mapType = JSON.parseObject(inputParam.getParam().getExportData(), LinkedHashMap.class);");
            method.addBodyLine("ExportExcel exportExcelOut = ExportExcelUtil.exportLayoutContent(inputParam.getParam().getTitleName(),infoList.getList(), mapType);");
            method.addBodyLine("return byteToResponseEntityExport(exportExcelOut);");
        });

        Method method = new Method("byteToResponseEntityExport");
        method.setVisibility(JavaVisibility.PUBLIC);
        FullyQualifiedJavaType javaType = new FullyQualifiedJavaType("com.hundsun.amc.model.ExportExcel");
        method.addParameter(new Parameter(javaType,"exportExcelOut"));
        FullyQualifiedJavaType retType = new FullyQualifiedJavaType("org.springframework.http.ResponseEntity");
        retType.addTypeArgument(new FullyQualifiedJavaType("byte[]"));
        method.setReturnType(retType);
        topLevelClass.addMethod(method);
        topLevelClass.addImportedType(retType);
        topLevelClass.addImportedType(javaType);
        method.addBodyLine("HttpHeaders headers = new HttpHeaders();");
        method.addBodyLine("headers.add(\"Content-Type\", \"application/octet-stream;charset=UTF-8\");");
        method.addBodyLine("try {");
        method.addBodyLine("headers.add(\"Content-Disposition\", \"attachment;filename=\"");
        method.addBodyLine("+ URLEncoder.encode(exportExcelOut.getFileName(), \"UTF-8\").replaceAll(\"\\\\+\", \"%20\"));");
        method.addBodyLine("} catch (UnsupportedEncodingException e) {");
        method.addBodyLine("throw new BaseBizException(\"无法编码文件名\", e);");
        method.addBodyLine("}");
        method.addBodyLine("return new ResponseEntity<>(exportExcelOut.getFileContent(), headers, HttpStatus.OK);");
    }

    private FullyQualifiedJavaType getSuperClass() {
        FullyQualifiedJavaType superClass = null;
        /*introspectedTable*/
        if (introspectedTable.getRules().generateJavaService()) {

            JavaServiceGeneratorConfiguration configuration = context.getJavaServiceGeneratorConfiguration();
            String substring = configuration.getTargetPackage() + ".http.IDownload" + introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "HttpService";
            superClass = new FullyQualifiedJavaType(substring);
        } else {
            String rootClass = getRootClass();
            if (rootClass != null) {
                superClass = new FullyQualifiedJavaType(rootClass);
            } else {
                superClass = null;
            }
        }

        return superClass;
    }

    private boolean includePrimaryKeyColumns() {
        return !introspectedTable.getRules().generatePrimaryKeyClass()
                && introspectedTable.hasPrimaryKeyColumns();
    }

    private boolean includeBLOBColumns() {
        return !introspectedTable.getRules().generateRecordWithBLOBsClass()
                && introspectedTable.hasBLOBColumns();
    }

    private void addParameterizedConstructor(TopLevelClass topLevelClass) {
        Method method = new Method(topLevelClass.getType().getShortName());
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setConstructor(true);
        method.setName(topLevelClass.getType().getShortName());
        context.getCommentGenerator().addGeneralMethodComment(method, introspectedTable);

        List<IntrospectedColumn> constructorColumns =
                includeBLOBColumns() ? introspectedTable.getAllColumns() :
                        introspectedTable.getNonBLOBColumns();

        for (IntrospectedColumn introspectedColumn : constructorColumns) {
            method.addParameter(new Parameter(introspectedColumn.getFullyQualifiedJavaType(),
                    introspectedColumn.getJavaProperty()));
            topLevelClass.addImportedType(introspectedColumn.getFullyQualifiedJavaType());
        }

        StringBuilder sb = new StringBuilder();
        if (introspectedTable.getRules().generatePrimaryKeyClass()) {
            boolean comma = false;
            sb.append("super("); //$NON-NLS-1$
            for (IntrospectedColumn introspectedColumn : introspectedTable
                    .getPrimaryKeyColumns()) {
                if (comma) {
                    sb.append(", "); //$NON-NLS-1$
                } else {
                    comma = true;
                }
                sb.append(introspectedColumn.getJavaProperty());
            }
            sb.append(");"); //$NON-NLS-1$
            method.addBodyLine(sb.toString());
        }

        List<IntrospectedColumn> introspectedColumns = getColumnsInThisClass();

        for (IntrospectedColumn introspectedColumn : introspectedColumns) {
            sb.setLength(0);
            sb.append("this."); //$NON-NLS-1$
            sb.append(introspectedColumn.getJavaProperty());
            sb.append(" = "); //$NON-NLS-1$
            sb.append(introspectedColumn.getJavaProperty());
            sb.append(';');
            method.addBodyLine(sb.toString());
        }

        topLevelClass.addMethod(method);
    }

    private List<IntrospectedColumn> getColumnsInThisClass() {
        List<IntrospectedColumn> introspectedColumns;
        if (includePrimaryKeyColumns()) {
            if (includeBLOBColumns()) {
                introspectedColumns = introspectedTable.getAllColumns();
            } else {
                introspectedColumns = introspectedTable.getNonBLOBColumns();
            }
        } else {
            if (includeBLOBColumns()) {
                introspectedColumns = introspectedTable
                        .getNonPrimaryKeyColumns();
            } else {
                introspectedColumns = introspectedTable.getBaseColumns();
            }
        }

        return introspectedColumns;
    }
}
