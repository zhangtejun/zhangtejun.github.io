/*
 *    Copyright 2006-2020 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.generator.codegen.mybatis3.xmlmapper.elements;

import java.util.ArrayList;
import java.util.List;
import org.mybatis.generator.api.IntrospectedColumn;
import org.mybatis.generator.api.dom.OutputUtilities;
import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
import org.mybatis.generator.api.dom.xml.Attribute;
import org.mybatis.generator.api.dom.xml.TextElement;
import org.mybatis.generator.api.dom.xml.XmlElement;
import org.mybatis.generator.codegen.mybatis3.ListUtilities;
import org.mybatis.generator.codegen.mybatis3.MyBatis3FormattingUtilities;
import org.mybatis.generator.config.GeneratedKey;

public class InsertBatchElementGenerator extends AbstractXmlElementGenerator {
    private boolean isSimple;

    public InsertBatchElementGenerator(boolean isSimple) {
        this.isSimple = isSimple;
    }

    public void addElements(XmlElement parentElement) {
        XmlElement answer = new XmlElement("insert");
        answer.addAttribute(new Attribute("id", this.introspectedTable
                .getInsertBatchStatementId()));
        FullyQualifiedJavaType parameterType = FullyQualifiedJavaType.getNewListInstance();
        answer.addAttribute(new Attribute("parameterType", parameterType
                .getFullyQualifiedName()));
        this.context.getCommentGenerator().addComment(answer);
        GeneratedKey gk = this.introspectedTable.getGeneratedKey();
        if (gk != null) {

            introspectedTable.getColumn(gk.getColumn()).ifPresent(introspectedColumn -> {
                // if the column is null, then it's a configuration error. The
                // warning has already been reported
                if (gk.isJdbcStandard()) {
                    answer.addAttribute(new Attribute("useGeneratedKeys", "true"));
                    answer.addAttribute(new Attribute("keyProperty", introspectedColumn
                            .getJavaProperty()));
                    answer.addAttribute(new Attribute("keyColumn", introspectedColumn
                            .getActualColumnName()));
                } else {
                    answer.addElement(getSelectKey(introspectedColumn, gk));
                }
            });
        }
        StringBuilder insertClause = new StringBuilder();
        StringBuilder valuesClause = new StringBuilder();
        insertClause.append("insert into ");
        insertClause.append(this.introspectedTable
                .getFullyQualifiedTableNameAtRuntime());
        insertClause.append(" (");
        valuesClause.append("SELECT ");
        List<String> valuesClauses = new ArrayList<>();
        List<IntrospectedColumn> columns = ListUtilities.removeIdentityAndGeneratedAlwaysColumns(this.introspectedTable.getAllColumns());
        String enableInsertBatchIgnore = this.introspectedTable.getTableConfiguration().getProperty("enableInsertBatchIgnore");
        String[] enableInsertBatchIgnores = null;
        if (enableInsertBatchIgnore != null)
            enableInsertBatchIgnores = enableInsertBatchIgnore.split(",");
        for (int i = 0; i < columns.size(); i++) {
            IntrospectedColumn introspectedColumn = columns.get(i);
            boolean ignore = false;
            if (enableInsertBatchIgnores != null && enableInsertBatchIgnores.length > 0)
                for (int j = 0; j < enableInsertBatchIgnores.length; j++) {
                    if (enableInsertBatchIgnores[j].equals(introspectedColumn.getJavaProperty())) {
                        ignore = true;
                        break;
                    }
                }
            if (!ignore) {
                insertClause.append(
                        MyBatis3FormattingUtilities.getEscapedColumnName(introspectedColumn));
                valuesClause.append(
                        MyBatis3FormattingUtilities.getParameterClause(introspectedColumn, "item."));
                if (i + 1 < columns.size()) {
                    insertClause.append(", ");
                    valuesClause.append(", ");
                }
                if (valuesClause.length() > 80) {
                    answer.addElement(new TextElement(insertClause.toString()));
                    insertClause.setLength(0);
                    OutputUtilities.xmlIndent(insertClause, 1);
                    valuesClauses.add(valuesClause.toString());
                    valuesClause.setLength(0);
                    OutputUtilities.xmlIndent(valuesClause, 1);
                }
            }
        }
        insertClause.append(')');
        answer.addElement(new TextElement(insertClause.toString()));
        valuesClause.append(" FROM DUAL");
        valuesClauses.add(valuesClause.toString());
        XmlElement outerForEachElement = new XmlElement("foreach");
        outerForEachElement.addAttribute(new Attribute("collection", "list"));
        outerForEachElement.addAttribute(new Attribute("item", "item"));
        outerForEachElement.addAttribute(new Attribute("open", "("));
        outerForEachElement.addAttribute(new Attribute("close", ")"));
        outerForEachElement.addAttribute(new Attribute("separator", "UNION"));
        for (String clause : valuesClauses)
            outerForEachElement.addElement(new TextElement(clause));
        answer.addElement(outerForEachElement);
        if (this.context.getPlugins().sqlMapInsertElementGenerated(answer, this.introspectedTable))
            parentElement.addElement(answer);
    }
}
