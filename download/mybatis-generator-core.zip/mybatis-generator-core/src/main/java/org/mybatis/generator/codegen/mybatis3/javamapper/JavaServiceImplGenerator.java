/*
 *    Copyright 2006-2020 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.generator.codegen.mybatis3.javamapper;


import org.mybatis.generator.api.*;
import org.mybatis.generator.api.dom.java.*;
import org.mybatis.generator.codegen.AbstractJavaGenerator;
import org.mybatis.generator.codegen.RootClassInfo;
import org.mybatis.generator.config.Context;
import org.mybatis.generator.internal.util.JavaBeansUtil;

import java.util.ArrayList;
import java.util.List;

import static org.mybatis.generator.internal.util.JavaBeansUtil.*;
import static org.mybatis.generator.internal.util.messages.Messages.getString;

public class JavaServiceImplGenerator extends AbstractJavaGenerator {

    public JavaServiceImplGenerator(String project) {
        super(project);
    }

    @Override
    public List<CompilationUnit> getCompilationUnits() {
        FullyQualifiedTable table = introspectedTable.getFullyQualifiedTable();
        progressCallback.startTask(getString(
                "Progress.8", table.toString())); //$NON-NLS-1$
        Plugin plugins = context.getPlugins();
        CommentGenerator commentGenerator = context.getCommentGenerator();

        FullyQualifiedJavaType type = new FullyQualifiedJavaType(
                introspectedTable.getServiceImplementationType());

        TopLevelClass topLevelClass = new TopLevelClass(type);
        topLevelClass.addAnnotation("@Service");
        topLevelClass.addAnnotation("@Transactional");
        topLevelClass.setVisibility(JavaVisibility.PUBLIC);
        commentGenerator.addJavaFileComment(topLevelClass);

        // set OutputDTO
        FullyQualifiedJavaType type2 = new FullyQualifiedJavaType(context.getJavaServiceGeneratorConfiguration().getDtoDirectory() + introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "InputDTO");
        topLevelClass.addImportedType(type2);

        // set OutputDTO
        FullyQualifiedJavaType type3 = new FullyQualifiedJavaType(context.getJavaServiceGeneratorConfiguration().getDtoDirectory()+ introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "OutputDTO");
        topLevelClass.addImportedType(type3);

        FullyQualifiedJavaType superClass = getSuperClass();
        if (superClass != null) {
            //topLevelClass.setSuperClass(superClass);

            topLevelClass.addImportedType(superClass);
            //topLevelClass
            topLevelClass.addSuperInterface(superClass);
        }
        commentGenerator.addModelClassComment(topLevelClass, introspectedTable);

        List<IntrospectedColumn> introspectedColumns = getColumnsInThisClass();


        topLevelClass.addImportedType(introspectedTable.getMyBatis3JavaMapperType());
        topLevelClass.addImportedType(FullyQualifiedJavaType.getNewListInstance());
        topLevelClass.addImportedType(introspectedTable.getRules().calculateAllFieldsClass());//

        topLevelClass.addImportedType(new FullyQualifiedJavaType("org.springframework.beans.factory.annotation.Autowired;"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("org.springframework.transaction.annotation.Transactional"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("org.springframework.stereotype.Service"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("com.github.pagehelper.PageInfo"));

        topLevelClass.addImportedType(new FullyQualifiedJavaType("java.util.stream.Collectors"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("com.hundsun.amc.utils.BeanMapUtils"));

        FullyQualifiedJavaType mapperType= new FullyQualifiedJavaType(introspectedTable.getMyBatis3JavaMapperType());
        Field field = new Field(JavaBeansUtil.firstCharLowcase(mapperType.getShortName()),mapperType);
        field.setName(JavaBeansUtil.firstCharLowcase(mapperType.getShortName())); //$NON-NLS-1$
        field.setType(mapperType); //$NON-NLS-1$
        field.setVisibility(JavaVisibility.PRIVATE);
        field.addAnnotation("@Autowired");

        // topLevelClass.addField(field); // TODO 屏蔽mapper 注入

         // 增加atom

        // 实现类全路径
        String interfaceType = introspectedTable.getServiceInterfaceType();
        int i = interfaceType.lastIndexOf(".");
        String pk = interfaceType.substring(0,i);
        String su = interfaceType.substring(i+1);

        //
        String domainObjectName = introspectedTable.getFullyQualifiedTable().getDomainObjectName();

        // 导入包
        topLevelClass.addImportedType(new FullyQualifiedJavaType(pk + ".atom.I"+domainObjectName+"Atom"));

        FullyQualifiedJavaType mapperType1 = new FullyQualifiedJavaType("I"+domainObjectName+"Atom");
        Field field1 = new Field(JavaBeansUtil.firstCharLowcase(mapperType1.getShortName()),mapperType1);
        field1.setName(JavaBeansUtil.firstCharLowcase(mapperType1.getShortName())); //$NON-NLS-1$
        field1.setType(mapperType1); //$NON-NLS-1$
        field1.setVisibility(JavaVisibility.PRIVATE);
        field1.addAnnotation("@Autowired");

        topLevelClass.addField(field1);


        FullyQualifiedJavaType parameterType = FullyQualifiedJavaType.getNewListInstance();
        parameterType.addTypeArgument(new FullyQualifiedJavaType(introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "InputDTO"));
        String methodName = introspectedTable.getInsertBatchStatementId();
        if (introspectedTable.getRules().generateInsertBatch()) {
            Method method = new Method(methodName);
            method.setVisibility(JavaVisibility.PUBLIC);
            method.addParameter(new Parameter(parameterType,"list"));
            method.setReturnType(FullyQualifiedJavaType.getIntInstance());
            String qualifiedName = introspectedTable.getRules().calculateAllFieldsClass().getShortName();
            method.setName(methodName); //$NON-NLS-1$

            method.addBodyLine("List<"+introspectedTable.getRules().calculateAllFieldsClass().getShortName()+"> inputList = list.stream()" +
                    ".map(e -> BeanMapUtils.copyPropertiesDeeply(e, "+introspectedTable.getRules().calculateAllFieldsClass().getShortName()+".class)).collect(Collectors.toList());");

            method.addBodyLine("return i"+qualifiedName + "Atom."+methodName+"(inputList);");
            commentGenerator.addGeneralMethodComment(method, introspectedTable);
            topLevelClass.addMethod(method);
        }
        if (introspectedTable.isConstructorBased()) {
            addParameterizedConstructor(topLevelClass);

            if (!introspectedTable.isImmutable()) {
                addDefaultConstructor(topLevelClass);
            }
        }
        addListMethod(topLevelClass);
        addGetMethod(topLevelClass);
        addSaveMethod(topLevelClass);
        addDeleteMethod(topLevelClass);
        addUpdateMethod(topLevelClass);
        String rootClass = getRootClass();
        List<CompilationUnit> answer = new ArrayList<CompilationUnit>();
        if (context.getPlugins().modelBaseRecordClassGenerated(
                topLevelClass, introspectedTable)) {
            answer.add(topLevelClass);
        }
        return answer;
    }
    public void addListMethod(TopLevelClass topLevelClass){
        FullyQualifiedJavaType mapperType= new FullyQualifiedJavaType(introspectedTable.getMyBatis3JavaMapperType());
        String mapperName = JavaBeansUtil.firstCharLowcase(mapperType.getShortName());
        Method method = new Method(mapperName);
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName("list");
        FullyQualifiedJavaType resultType = new FullyQualifiedJavaType("com.github.pagehelper.PageInfo");
        FullyQualifiedJavaType exampleType = new FullyQualifiedJavaType(introspectedTable.getExampleType());
        // WbinsInsSource
        String qualifiedName = introspectedTable.getRules().calculateAllFieldsClass().getShortName();
        resultType.addTypeArgument(new FullyQualifiedJavaType(introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "OutputDTO"));
        //resultType.addTypeArgument(introspectedTable.getRules().calculateAllFieldsClass());
        method.setReturnType(resultType);

        method.addBodyLine("return i"+qualifiedName + "Atom.list(param,pageNo,pageSize);");

        FullyQualifiedJavaType listType = new FullyQualifiedJavaType(introspectedTable.getRules().calculateAllFieldsClass() + "InputDTO");
        method.addParameter(new Parameter(new FullyQualifiedJavaType(listType.getShortName()),"param"));

        method.addParameter(new Parameter(FullyQualifiedJavaType.getIntInstance(),"pageNo"));
        method.addParameter(new Parameter(FullyQualifiedJavaType.getIntInstance(),"pageSize"));



        topLevelClass.addMethod(method);
    }


    public void addGetMethod(TopLevelClass topLevelClass){
        String qualifiedName = introspectedTable.getRules().calculateAllFieldsClass().getShortName();
        String mapperName = "i"+qualifiedName + "Atom";
        Method method = new Method("get");
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName("get");
        method.setReturnType(new FullyQualifiedJavaType(introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "OutputDTO"));
        method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(),"id"));
        method.addBodyLine("return " + mapperName + ".get(id);");
        topLevelClass.addMethod(method);
    }
    public void addSaveMethod(TopLevelClass topLevelClass){
        String qualifiedName = introspectedTable.getRules().calculateAllFieldsClass().getShortName();
        String mapperName = "i"+qualifiedName + "Atom";
        FullyQualifiedJavaType mapperType= new FullyQualifiedJavaType(introspectedTable.getMyBatis3JavaMapperType());
        Method method = new Method("save");
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName("save");
        method.addParameter(new Parameter(new FullyQualifiedJavaType(introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "InputDTO"),"toDB"));
        method.addBodyLine(mapperName + ".save(BeanMapUtils.copyPropertiesDeeply(toDB,"+introspectedTable.getRules().calculateAllFieldsClass().getShortName()+".class));");
        topLevelClass.addMethod(method);
    }
    public void addDeleteMethod(TopLevelClass topLevelClass){
        String qualifiedName = introspectedTable.getRules().calculateAllFieldsClass().getShortName();
        String mapperName = "i"+qualifiedName + "Atom";
        FullyQualifiedJavaType mapperType= new FullyQualifiedJavaType(introspectedTable.getMyBatis3JavaMapperType());
        Method method = new Method("delete");
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName("delete");
        method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(),"id"));
        method.addBodyLine(mapperName + ".delete(id);");
        topLevelClass.addMethod(method);
    }

    public void addUpdateMethod(TopLevelClass topLevelClass){
        String qualifiedName = introspectedTable.getRules().calculateAllFieldsClass().getShortName();
        String mapperName = "i"+qualifiedName + "Atom";
        FullyQualifiedJavaType mapperType= new FullyQualifiedJavaType(introspectedTable.getMyBatis3JavaMapperType());
        Method method = new Method("update");
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName("update");
        method.addParameter(new Parameter(new FullyQualifiedJavaType(introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "InputDTO"),"toDB"));
        method.addBodyLine(mapperName + ".update(BeanMapUtils.copyPropertiesDeeply(toDB,"+introspectedTable.getRules().calculateAllFieldsClass().getShortName()+".class));");
        topLevelClass.addMethod(method);
    }
    private FullyQualifiedJavaType getSuperClass() {
        FullyQualifiedJavaType superClass = null;
        /*introspectedTable*/
        if (introspectedTable.getRules().generateJavaService()) {
            // TODO
            String substring = introspectedTable.getServiceImplementationType().substring(0, introspectedTable.getServiceImplementationType().length() - 4);
            substring = substring.replace(".impl.",".");
            // superClass = new FullyQualifiedJavaType(introspectedTable.getServiceInterfaceType());
            superClass = new FullyQualifiedJavaType(substring);
        } else {
            String rootClass = getRootClass();
            if (rootClass != null) {
                superClass = new FullyQualifiedJavaType(rootClass);
            } else {
                superClass = null;
            }
        }

        return superClass;
    }

    private boolean includePrimaryKeyColumns() {
        return !introspectedTable.getRules().generatePrimaryKeyClass()
                && introspectedTable.hasPrimaryKeyColumns();
    }

    private boolean includeBLOBColumns() {
        return !introspectedTable.getRules().generateRecordWithBLOBsClass()
                && introspectedTable.hasBLOBColumns();
    }

    private void addParameterizedConstructor(TopLevelClass topLevelClass) {
        Method method = new Method(topLevelClass.getType().getShortName());
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setConstructor(true);
        method.setName(topLevelClass.getType().getShortName());
        context.getCommentGenerator().addGeneralMethodComment(method, introspectedTable);

        List<IntrospectedColumn> constructorColumns =
                includeBLOBColumns() ? introspectedTable.getAllColumns() :
                        introspectedTable.getNonBLOBColumns();

        for (IntrospectedColumn introspectedColumn : constructorColumns) {
            method.addParameter(new Parameter(introspectedColumn.getFullyQualifiedJavaType(),
                    introspectedColumn.getJavaProperty()));
            topLevelClass.addImportedType(introspectedColumn.getFullyQualifiedJavaType());
        }

        StringBuilder sb = new StringBuilder();
        if (introspectedTable.getRules().generatePrimaryKeyClass()) {
            boolean comma = false;
            sb.append("super("); //$NON-NLS-1$
            for (IntrospectedColumn introspectedColumn : introspectedTable
                    .getPrimaryKeyColumns()) {
                if (comma) {
                    sb.append(", "); //$NON-NLS-1$
                } else {
                    comma = true;
                }
                sb.append(introspectedColumn.getJavaProperty());
            }
            sb.append(");"); //$NON-NLS-1$
            method.addBodyLine(sb.toString());
        }

        List<IntrospectedColumn> introspectedColumns = getColumnsInThisClass();

        for (IntrospectedColumn introspectedColumn : introspectedColumns) {
            sb.setLength(0);
            sb.append("this."); //$NON-NLS-1$
            sb.append(introspectedColumn.getJavaProperty());
            sb.append(" = "); //$NON-NLS-1$
            sb.append(introspectedColumn.getJavaProperty());
            sb.append(';');
            method.addBodyLine(sb.toString());
        }

        topLevelClass.addMethod(method);
    }

    private List<IntrospectedColumn> getColumnsInThisClass() {
        List<IntrospectedColumn> introspectedColumns;
        if (includePrimaryKeyColumns()) {
            if (includeBLOBColumns()) {
                introspectedColumns = introspectedTable.getAllColumns();
            } else {
                introspectedColumns = introspectedTable.getNonBLOBColumns();
            }
        } else {
            if (includeBLOBColumns()) {
                introspectedColumns = introspectedTable
                        .getNonPrimaryKeyColumns();
            } else {
                introspectedColumns = introspectedTable.getBaseColumns();
            }
        }

        return introspectedColumns;
    }
}
