/*
 *    Copyright 2006-2020 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.generator.codegen.mybatis3.javamapper;


import org.mybatis.generator.api.CommentGenerator;
import org.mybatis.generator.api.FullyQualifiedTable;
import org.mybatis.generator.api.IntrospectedColumn;
import org.mybatis.generator.api.Plugin;
import org.mybatis.generator.api.dom.java.*;
import org.mybatis.generator.codegen.AbstractJavaGenerator;
import org.mybatis.generator.config.JavaServiceGeneratorConfiguration;
import org.mybatis.generator.internal.util.JavaBeansUtil;

import java.util.ArrayList;
import java.util.List;

import static org.mybatis.generator.internal.util.messages.Messages.getString;

public class JavaApiImplGenerator extends AbstractJavaGenerator {
    String serverApi;

    public void setServerApi(String serverApi) {
        this.serverApi = serverApi;
    }

    public JavaApiImplGenerator(String project) {
        super(project);
    }

    @Override
    public List<CompilationUnit> getCompilationUnits() {
        FullyQualifiedTable table = introspectedTable.getFullyQualifiedTable();
        progressCallback.startTask(getString(
                "Progress.8", table.toString())); //$NON-NLS-1$
        Plugin plugins = context.getPlugins();
        CommentGenerator commentGenerator = context.getCommentGenerator();

        // FullyQualifiedJavaType type = new FullyQualifiedJavaType(introspectedTable.getServiceImplementationType());


        // 实现类全路径
        String interfaceType = introspectedTable.getServiceInterfaceType();
        int i = interfaceType.lastIndexOf(".");
        String pk = interfaceType.substring(0,i);
        String su = interfaceType.substring(i+1);

        //
        String domainObjectName = introspectedTable.getFullyQualifiedTable().getDomainObjectName();


        FullyQualifiedJavaType type = new FullyQualifiedJavaType(pk + ".api.impl."+domainObjectName+"ApiServiceImpl");

        TopLevelClass topLevelClass = new TopLevelClass(type);
        topLevelClass.addAnnotation("@Service");
        topLevelClass.addAnnotation("@Transactional");
        topLevelClass.setVisibility(JavaVisibility.PUBLIC);
        commentGenerator.addJavaFileComment(topLevelClass);

        FullyQualifiedJavaType superClass = getSuperClass();
        if (superClass != null) {
            //topLevelClass.setSuperClass(superClass);

            topLevelClass.addImportedType(superClass);
            //topLevelClass
            topLevelClass.addSuperInterface(superClass);
        }
        commentGenerator.addModelClassComment(topLevelClass, introspectedTable);

        List<IntrospectedColumn> introspectedColumns = getColumnsInThisClass();


        // topLevelClass.addImportedType(introspectedTable.getMyBatis3JavaMapperType());
        //topLevelClass.addImportedType(FullyQualifiedJavaType.getNewListInstance());
        // topLevelClass.addImportedType(introspectedTable.getRules().calculateAllFieldsClass());//

        topLevelClass.addImportedType(new FullyQualifiedJavaType("org.springframework.beans.factory.annotation.Autowired"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("org.springframework.transaction.annotation.Transactional"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("org.springframework.stereotype.Service"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("com.github.pagehelper.PageInfo"));
        topLevelClass.addImportedType("org.springframework.util.Assert");
        topLevelClass.addImportedType("org.springframework.util.CollectionUtils");
        topLevelClass.addImportedType("org.springframework.util.StringUtils");

        FullyQualifiedJavaType mapperType= new FullyQualifiedJavaType(introspectedTable.getMyBatis3JavaMapperType());
        Field field = new Field(JavaBeansUtil.firstCharLowcase(mapperType.getShortName()),mapperType);
        field.setName(JavaBeansUtil.firstCharLowcase(mapperType.getShortName())); //$NON-NLS-1$
        field.setType(mapperType); //$NON-NLS-1$
        field.setVisibility(JavaVisibility.PRIVATE);
        field.addAnnotation("@Autowired");

        // topLevelClass.addField(field); // TODO 屏蔽mapper 注入

         // 自动注入信息

        // 导入包 web 层的service
        topLevelClass.addImportedType(new FullyQualifiedJavaType(pk + ".service."+domainObjectName+"Service"));

        FullyQualifiedJavaType mapperType1 = new FullyQualifiedJavaType(domainObjectName+"Service");
        String serverApi = JavaBeansUtil.firstCharLowcase(mapperType1.getShortName());
        //
        setServerApi(serverApi);

        Field field1 = new Field(serverApi,mapperType1);
        field1.setName(serverApi); //$NON-NLS-1$
        field1.setType(mapperType1); //$NON-NLS-1$
        field1.setVisibility(JavaVisibility.PRIVATE);
        field1.addAnnotation("@Autowired");

        topLevelClass.addField(field1);


        FullyQualifiedJavaType parameterType = FullyQualifiedJavaType.getNewListInstance();
        parameterType.addTypeArgument(introspectedTable.getRules().calculateAllFieldsClass());
        String methodName = introspectedTable.getInsertBatchStatementId();
        if (introspectedTable.getRules().generateInsertBatch()) {
            Method method = new Method(methodName);
            method.setVisibility(JavaVisibility.PUBLIC);

            // 类路径
            FullyQualifiedJavaType type1 = new FullyQualifiedJavaType(context.getJavaServiceGeneratorConfiguration().getDtoDirectory() + introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "InputDTO");
            // 类路径
            FullyQualifiedJavaType request = new FullyQualifiedJavaType("com.hundsun.amc.model.RequestDTO");
            // 参数
            FullyQualifiedJavaType requestParam = new FullyQualifiedJavaType("RequestDTO");
            // 类名

            FullyQualifiedJavaType listInstance = new FullyQualifiedJavaType("List");
            listInstance.addTypeArgument(new FullyQualifiedJavaType(type1.getShortName()));
            requestParam.addTypeArgument(listInstance);

            topLevelClass.addImportedType(type1);
            topLevelClass.addImportedType(request);
            topLevelClass.addImportedType("com.hundsun.jrescloud.rpc.result.RpcResultDTO");
            topLevelClass.addImportedType("org.springframework.beans.BeanUtils");
            topLevelClass.addImportedType("java.util.List");
            topLevelClass.addImportedType("com.hundsun.amc.utils.BeanMapUtils");
            topLevelClass.addImportedType("java.util.stream.Collectors");


            // 设置到参数
            method.addParameter(new Parameter(requestParam,"list"));

            FullyQualifiedJavaType returnType = new FullyQualifiedJavaType("RpcResultDTO");
            returnType.addTypeArgument(new FullyQualifiedJavaType("Integer"));
            method.setReturnType(returnType);


            String qualifiedName = introspectedTable.getRules().calculateAllFieldsClass().getShortName();
            method.setName(methodName); //$NON-NLS-1$

            method.addBodyLine("Assert.isTrue(list != null && !CollectionUtils.isEmpty(list.getParam()) ,\""+methodName+" error inputParam is null\");");
             method.addBodyLine(returnType.getShortName() + " out = new RpcResultDTO<>();");
            // method.addBodyLine("BeanUtils.copyProperties(list,out);");

            method.addBodyLine("int batch =  " + serverApi + "."+methodName+"(list.getParam());");
            method.addBodyLine("out.setResult(batch);");
            method.addBodyLine("return out;");
            topLevelClass.addImportedType(introspectedTable.getRules().calculateAllFieldsClass());

            commentGenerator.addGeneralMethodComment(method, introspectedTable);
            topLevelClass.addMethod(method);
        }
        if (introspectedTable.isConstructorBased()) {
            addParameterizedConstructor(topLevelClass);

            if (!introspectedTable.isImmutable()) {
                addDefaultConstructor(topLevelClass);
            }
        }
        addListMethod(topLevelClass);
        addGetMethod(topLevelClass);
        addSaveMethod(topLevelClass);
        addDeleteMethod(topLevelClass);
        addUpdateMethod(topLevelClass);
        String rootClass = getRootClass();
        List<CompilationUnit> answer = new ArrayList<CompilationUnit>();
        if (context.getPlugins().modelBaseRecordClassGenerated(
                topLevelClass, introspectedTable)) {
            answer.add(topLevelClass);
        }
        return answer;
    }
    public void addListMethod(TopLevelClass topLevelClass){
        FullyQualifiedJavaType mapperType= new FullyQualifiedJavaType(introspectedTable.getMyBatis3JavaMapperType());
        String mapperName = JavaBeansUtil.firstCharLowcase(mapperType.getShortName());
        Method method = new Method(mapperName);
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName("list");
        FullyQualifiedJavaType request = new FullyQualifiedJavaType("com.hundsun.amc.model.RequestDTO");
        FullyQualifiedJavaType param = new FullyQualifiedJavaType(introspectedTable.getRules().calculateAllFieldsClass().getShortName()+ "InputDTO");
        request.addTypeArgument(param);
        method.addParameter(0,new Parameter(request,"inputParam"));
        FullyQualifiedJavaType first = new FullyQualifiedJavaType("com.hundsun.jrescloud.rpc.result.RpcResultDTO");

        FullyQualifiedJavaType resultType = new FullyQualifiedJavaType("com.github.pagehelper.PageInfo");
        FullyQualifiedJavaType exampleType = new FullyQualifiedJavaType(introspectedTable.getExampleType());
        // WbinsInsSource
        first.addTypeArgument(resultType);
        FullyQualifiedJavaType type1 = new FullyQualifiedJavaType(context.getJavaServiceGeneratorConfiguration().getDtoDirectory() + introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "OutputDTO");
        resultType.addTypeArgument(new FullyQualifiedJavaType(introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "OutputDTO"));
        //resultType.addTypeArgument(introspectedTable.getRules().calculateAllFieldsClass());
        topLevelClass.addImportedType(exampleType);
        topLevelClass.addImportedType(type1);
        method.setReturnType(first);
        method.addBodyLine("Assert.isTrue(inputParam!= null && inputParam.getParam() != null ,\""+method.getName()+" error inputParam is null\");");
        method.addBodyLine(first.getShortName() + " out = new RpcResultDTO<>();");
        method.addBodyLine("out.setResult("+""+serverApi + ".list(inputParam.getParam(),inputParam.getPageNo(),inputParam.getPageSize()));");
        method.addBodyLine("return out;");
        topLevelClass.addMethod(method);
    }


    public void addGetMethod(TopLevelClass topLevelClass){
        String mapperName = serverApi;
        Method method = new Method("get");
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName("get");
        topLevelClass.addImportedType(new FullyQualifiedJavaType("java.lang.String"));
        topLevelClass.addImportedType(new FullyQualifiedJavaType("java.lang.Void"));
        FullyQualifiedJavaType first = new FullyQualifiedJavaType("com.hundsun.jrescloud.rpc.result.RpcResultDTO");
        // set OutputDTO
        FullyQualifiedJavaType type2 = new FullyQualifiedJavaType(context.getJavaServiceGeneratorConfiguration().getDtoDirectory()+ introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "OutputDTO");
        topLevelClass.addImportedType(type2);
        first.addTypeArgument(type2);

        method.setReturnType(first);
        FullyQualifiedJavaType request = new FullyQualifiedJavaType("com.hundsun.amc.model.RequestDTO");
        request.addTypeArgument(FullyQualifiedJavaType.getStringInstance());
        method.addParameter(new Parameter(request,"id"));
        method.addBodyLine("Assert.isTrue(id!= null && StringUtils.hasLength(id.getParam()) ,\""+method.getName()+" error id is null\");");
        method.addBodyLine(first.getShortName() + " out = new RpcResultDTO<>();");
        method.addBodyLine("out.setResult( "+mapperName + ".get(id.getParam()));");
        method.addBodyLine("return out;");
        topLevelClass.addMethod(method);
    }
    public void addSaveMethod(TopLevelClass topLevelClass){
        String mapperName = serverApi;
        FullyQualifiedJavaType mapperType= new FullyQualifiedJavaType(introspectedTable.getMyBatis3JavaMapperType());
        Method method = new Method("save");
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName("save");
        //
        // check data
        method.addBodyLine("// TODO");
        method.addBodyLine("/* ");
        method.addBodyLine(introspectedTable.getRules().calculateAllFieldsClass().getShortName()+"OutputDTO dto = this."+mapperName+".get(inputParam.getParam().getId());");
        method.addBodyLine("Assert.isTrue(dto != null && StringUtils.hasLength(dto.getId()),\" "+introspectedTable.getRules().calculateAllFieldsClass().getShortName() + method.getName()+" 该记录已存在\");");
        method.addBodyLine("*/");

        FullyQualifiedJavaType type = new FullyQualifiedJavaType(context.getJavaServiceGeneratorConfiguration().getDtoDirectory() + introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "InputDTO");
        FullyQualifiedJavaType request = new FullyQualifiedJavaType("com.hundsun.amc.model.RequestDTO");
        request.addTypeArgument(new FullyQualifiedJavaType(type.getShortName()));
        method.addParameter(new Parameter(request,"inputParam"));
        topLevelClass.addImportedType(type);
        method.addBodyLine("Assert.isTrue(inputParam!= null && inputParam.getParam() != null ,\""+method.getName()+" error inputParam is null\");");
        // method.addParameter(new Parameter(introspectedTable.getRules().calculateAllFieldsClass(),"toDB"));
        method.addBodyLine(mapperName + ".save(inputParam.getParam());");
        topLevelClass.addImportedType(new FullyQualifiedJavaType("java.lang.Void"));
        FullyQualifiedJavaType first = new FullyQualifiedJavaType("com.hundsun.jrescloud.rpc.result.RpcResultDTO");
        first.addTypeArgument(new FullyQualifiedJavaType("Void"));
        method.setReturnType(first);
        method.addBodyLine("return new RpcResultDTO<>();");
        topLevelClass.addMethod(method);
    }
    public void addDeleteMethod(TopLevelClass topLevelClass){
        String mapperName = serverApi;
        FullyQualifiedJavaType mapperType= new FullyQualifiedJavaType(introspectedTable.getMyBatis3JavaMapperType());
        Method method = new Method("delete");
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName("delete");
        topLevelClass.addImportedType(new FullyQualifiedJavaType("java.lang.Void"));
        FullyQualifiedJavaType first = new FullyQualifiedJavaType("com.hundsun.jrescloud.rpc.result.RpcResultDTO");
        first.addTypeArgument(new FullyQualifiedJavaType("Void"));
        method.setReturnType(first);

        FullyQualifiedJavaType type = new FullyQualifiedJavaType(context.getJavaServiceGeneratorConfiguration().getDtoDirectory() + introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "InputDTO");
        FullyQualifiedJavaType request = new FullyQualifiedJavaType("com.hundsun.amc.model.RequestDTO");
        request.addTypeArgument(new FullyQualifiedJavaType(type.getShortName()));
        method.addParameter(new Parameter(request,"inputParam"));
        topLevelClass.addImportedType(type);
        method.addBodyLine("Assert.isTrue(inputParam!= null && inputParam.getParam() != null ,\""+method.getName()+" error inputParam is null\");");
        // check data
        method.addBodyLine("// TODO");
        method.addBodyLine("/* ");
        method.addBodyLine(introspectedTable.getRules().calculateAllFieldsClass().getShortName()+"OutputDTO dto = this."+mapperName+".get(inputParam.getParam().getId());");
        method.addBodyLine("Assert.isTrue(dto != null && StringUtils.hasLength(dto.getId()),\" "+introspectedTable.getRules().calculateAllFieldsClass().getShortName() + method.getName()+" error 根据id  未查询到相关信息\");");
        method.addBodyLine("*/");

        //method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(),"id"));
        method.addBodyLine(" // TODO  "+mapperName + ".delete(inputParam.getParam().getId());");
        method.addBodyLine("return new RpcResultDTO<>();");
        topLevelClass.addMethod(method);
    }

    public void addUpdateMethod(TopLevelClass topLevelClass){
        String mapperName = serverApi;
        FullyQualifiedJavaType mapperType= new FullyQualifiedJavaType(introspectedTable.getMyBatis3JavaMapperType());
        Method method = new Method("update");
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName("update");
        topLevelClass.addImportedType(new FullyQualifiedJavaType("java.lang.Void"));
        FullyQualifiedJavaType first = new FullyQualifiedJavaType("com.hundsun.jrescloud.rpc.result.RpcResultDTO");
        first.addTypeArgument(new FullyQualifiedJavaType("Void"));
        method.setReturnType(first);
        method.addBodyLine("Assert.isTrue(inputParam!= null && inputParam.getParam() != null ,\""+method.getName()+" error inputParam is null\");");
        method.addBodyLine("// TODO");
        method.addBodyLine("/* ");
        method.addBodyLine(introspectedTable.getRules().calculateAllFieldsClass().getShortName()+"OutputDTO dto = this."+mapperName+".get(inputParam.getParam().getId());");
        method.addBodyLine("Assert.isTrue(dto != null && StringUtils.hasLength(dto.getId()),\" "+introspectedTable.getRules().calculateAllFieldsClass().getShortName() + method.getName()+" error 根据id  未查询到相关信息\");");
        method.addBodyLine("*/");
        FullyQualifiedJavaType type = new FullyQualifiedJavaType(context.getJavaServiceGeneratorConfiguration().getDtoDirectory() + introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "InputDTO");
        FullyQualifiedJavaType request = new FullyQualifiedJavaType("com.hundsun.amc.model.RequestDTO");
        request.addTypeArgument(new FullyQualifiedJavaType(type.getShortName()));
        method.addParameter(new Parameter(request,"inputParam"));
        topLevelClass.addImportedType(type);

        // method.addParameter(new Parameter(introspectedTable.getRules().calculateAllFieldsClass(),"toDB"));
        method.addBodyLine(mapperName + ".update(inputParam.getParam());");
        method.addBodyLine("return new RpcResultDTO<>();");
        topLevelClass.addMethod(method);
    }
    private FullyQualifiedJavaType getSuperClass() {
        FullyQualifiedJavaType superClass = null;
        /*introspectedTable*/
        if (introspectedTable.getRules().generateJavaService()) {

            JavaServiceGeneratorConfiguration configuration = context.getJavaServiceGeneratorConfiguration();
            String substring = configuration.getTargetPackage() + ".api." + introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "ApiService";
            superClass = new FullyQualifiedJavaType(substring);
        } else {
            String rootClass = getRootClass();
            if (rootClass != null) {
                superClass = new FullyQualifiedJavaType(rootClass);
            } else {
                superClass = null;
            }
        }

        return superClass;
    }

    private boolean includePrimaryKeyColumns() {
        return !introspectedTable.getRules().generatePrimaryKeyClass()
                && introspectedTable.hasPrimaryKeyColumns();
    }

    private boolean includeBLOBColumns() {
        return !introspectedTable.getRules().generateRecordWithBLOBsClass()
                && introspectedTable.hasBLOBColumns();
    }

    private void addParameterizedConstructor(TopLevelClass topLevelClass) {
        Method method = new Method(topLevelClass.getType().getShortName());
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setConstructor(true);
        method.setName(topLevelClass.getType().getShortName());
        context.getCommentGenerator().addGeneralMethodComment(method, introspectedTable);

        List<IntrospectedColumn> constructorColumns =
                includeBLOBColumns() ? introspectedTable.getAllColumns() :
                        introspectedTable.getNonBLOBColumns();

        for (IntrospectedColumn introspectedColumn : constructorColumns) {
            method.addParameter(new Parameter(introspectedColumn.getFullyQualifiedJavaType(),
                    introspectedColumn.getJavaProperty()));
            topLevelClass.addImportedType(introspectedColumn.getFullyQualifiedJavaType());
        }

        StringBuilder sb = new StringBuilder();
        if (introspectedTable.getRules().generatePrimaryKeyClass()) {
            boolean comma = false;
            sb.append("super("); //$NON-NLS-1$
            for (IntrospectedColumn introspectedColumn : introspectedTable
                    .getPrimaryKeyColumns()) {
                if (comma) {
                    sb.append(", "); //$NON-NLS-1$
                } else {
                    comma = true;
                }
                sb.append(introspectedColumn.getJavaProperty());
            }
            sb.append(");"); //$NON-NLS-1$
            method.addBodyLine(sb.toString());
        }

        List<IntrospectedColumn> introspectedColumns = getColumnsInThisClass();

        for (IntrospectedColumn introspectedColumn : introspectedColumns) {
            sb.setLength(0);
            sb.append("this."); //$NON-NLS-1$
            sb.append(introspectedColumn.getJavaProperty());
            sb.append(" = "); //$NON-NLS-1$
            sb.append(introspectedColumn.getJavaProperty());
            sb.append(';');
            method.addBodyLine(sb.toString());
        }

        topLevelClass.addMethod(method);
    }

    private List<IntrospectedColumn> getColumnsInThisClass() {
        List<IntrospectedColumn> introspectedColumns;
        if (includePrimaryKeyColumns()) {
            if (includeBLOBColumns()) {
                introspectedColumns = introspectedTable.getAllColumns();
            } else {
                introspectedColumns = introspectedTable.getNonBLOBColumns();
            }
        } else {
            if (includeBLOBColumns()) {
                introspectedColumns = introspectedTable
                        .getNonPrimaryKeyColumns();
            } else {
                introspectedColumns = introspectedTable.getBaseColumns();
            }
        }

        return introspectedColumns;
    }
}
