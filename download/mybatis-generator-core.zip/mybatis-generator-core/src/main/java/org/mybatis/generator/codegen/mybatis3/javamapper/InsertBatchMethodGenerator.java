/*
 *    Copyright 2006-2020 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.generator.codegen.mybatis3.javamapper;

import org.mybatis.generator.api.dom.java.FullyQualifiedJavaType;
import org.mybatis.generator.api.dom.java.Interface;
import org.mybatis.generator.codegen.mybatis3.javamapper.elements.AbstractJavaMapperMethodGenerator;

import java.util.Set;

import org.mybatis.generator.api.dom.java.*;
import org.mybatis.generator.internal.util.JavaBeansUtil;

import java.util.Set;
import java.util.TreeSet;
public class InsertBatchMethodGenerator extends AbstractJavaMapperMethodGenerator {

    private boolean isSimple;
    private boolean needRequest = true;
    private String retType;

    public InsertBatchMethodGenerator(boolean isSimple) {
        super();
        this.isSimple = isSimple;
    }
    public InsertBatchMethodGenerator(boolean isSimple,String retType) {
        this.isSimple = isSimple;
        this.retType = retType;
    }

    public InsertBatchMethodGenerator(boolean isSimple,String retType,boolean needRequest) {
        this.isSimple = isSimple;
        this.retType = retType;
        this.needRequest = needRequest;
    }

    @Override
    public void addInterfaceElements(Interface interfaze) {
        Set<FullyQualifiedJavaType> importedTypes = new TreeSet<FullyQualifiedJavaType>();
        importedTypes.add(FullyQualifiedJavaType.getNewListInstance());
        importedTypes.add(new FullyQualifiedJavaType("java.lang.Integer"));
        importedTypes.add(introspectedTable.getRules().calculateAllFieldsClass());

        Method method = new Method(introspectedTable.getInsertBatchStatementId());
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setAbstract(true);
        method.setName(introspectedTable.getInsertBatchStatementId());
        FullyQualifiedJavaType parameterType = FullyQualifiedJavaType.getNewListInstance();


        if (retType != null){  // 修改参数
            FullyQualifiedJavaType parameterTypeNew = new FullyQualifiedJavaType(retType);
            importedTypes.add(parameterTypeNew);
            parameterType.addTypeArgument(parameterTypeNew);
            FullyQualifiedJavaType type = new FullyQualifiedJavaType("RpcResultDTO");
            type.addTypeArgument(new FullyQualifiedJavaType("Integer"));


            FullyQualifiedJavaType first = new FullyQualifiedJavaType("com.hundsun.amc.model.RequestDTO");
            // set OutputDTO
            FullyQualifiedJavaType type2 = new FullyQualifiedJavaType(context.getJavaServiceGeneratorConfiguration().getDtoDirectory() + introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "InputDTO");
            interfaze.addImportedType(type2);

            FullyQualifiedJavaType listInstance = FullyQualifiedJavaType.getNewListInstance();
            listInstance.addTypeArgument(parameterTypeNew);
            first.addTypeArgument(listInstance);

            if (needRequest){
                parameterType = first;
                method.setReturnType(type);
            }else {
                parameterType = listInstance;
                method.setReturnType(FullyQualifiedJavaType.getIntInstance());
            }



        }else {
            method.setReturnType(FullyQualifiedJavaType.getIntInstance());
            parameterType.addTypeArgument(introspectedTable.getRules()
                    .calculateAllFieldsClass());
        }



        method.addParameter(new Parameter(parameterType, "list")); //$NON-NLS-1$
        /*if (isSimple) {
            parameterType = new FullyQualifiedJavaType(
                    introspectedTable.getBaseRecordType());
        } else {
            parameterType = introspectedTable.getRules()
                    .calculateAllFieldsClass();
        }*/


        context.getCommentGenerator().addGeneralMethodComment(method,
                introspectedTable);

        addMapperAnnotations(interfaze, method);

        if (context.getPlugins().clientInsertMethodGenerated(method, interfaze,
                introspectedTable)) {
            interfaze.addImportedTypes(importedTypes);
            interfaze.addMethod(method);
        }
    }

    public void addMapperAnnotations(Interface interfaze, Method method) {
        if (!isSimple)
        //method.addAnnotation("@CloudFunction( functionId = \"XXXXXX\", desc = \"XXXXXXXX说明\" )");
        method.addAnnotation("@CloudFunction(apiUrl = \""+introspectedTable.getRules().calculateAllFieldsClass().getShortName()+ JavaBeansUtil.getFirstCharacterUppercase(method.getName())+"\",functionId = \"XXXXXX\", desc = \""+introspectedTable.getRules().calculateAllFieldsClass().getShortName()+JavaBeansUtil.getFirstCharacterUppercase(method.getName())+"接口\" )");
    }
}
