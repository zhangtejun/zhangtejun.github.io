/*
 *    Copyright 2006-2020 the original author or authors.
 *
 *    Licensed under the Apache License, Version 2.0 (the "License");
 *    you may not use this file except in compliance with the License.
 *    You may obtain a copy of the License at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *    Unless required by applicable law or agreed to in writing, software
 *    distributed under the License is distributed on an "AS IS" BASIS,
 *    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *    See the License for the specific language governing permissions and
 *    limitations under the License.
 */
package org.mybatis.generator.codegen.mybatis3.javamapper;


import org.mybatis.generator.api.CommentGenerator;
import org.mybatis.generator.api.FullyQualifiedTable;
import org.mybatis.generator.api.dom.java.*;
import org.mybatis.generator.codegen.AbstractJavaClientGenerator;
import org.mybatis.generator.codegen.AbstractXmlGenerator;
import org.mybatis.generator.codegen.mybatis3.javamapper.elements.AbstractJavaMapperMethodGenerator;
import org.mybatis.generator.codegen.mybatis3.xmlmapper.XMLMapperGenerator;
import org.mybatis.generator.config.PropertyRegistry;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.mybatis.generator.internal.util.StringUtility.stringHasValue;
import static org.mybatis.generator.internal.util.messages.Messages.getString;

public class JavaAtomGenerator extends AbstractJavaClientGenerator {
    public JavaAtomGenerator(String project) {
        this(project, true);
    }

    public JavaAtomGenerator(String project, boolean requiresMatchedXMLGenerator) {
        super(project, requiresMatchedXMLGenerator);
    }

    @Override
    public List<CompilationUnit> getCompilationUnits() {
        progressCallback.startTask(getString("new_Progress.17", //$NON-NLS-1$
                introspectedTable.getFullyQualifiedTable().toString()));
        CommentGenerator commentGenerator = context.getCommentGenerator();
        // 实现类全路径
        String interfaceType = introspectedTable.getServiceInterfaceType();
        int i = interfaceType.lastIndexOf(".");
        String pk = interfaceType.substring(0,i);
        String su = interfaceType.substring(i+1);

        //
        String domainObjectName = introspectedTable.getFullyQualifiedTable().getDomainObjectName();


        FullyQualifiedJavaType type = new FullyQualifiedJavaType(pk + ".atom.I"+domainObjectName+"Atom");
        Interface interfaze = new Interface(type);
        interfaze.setVisibility(JavaVisibility.PUBLIC);
        commentGenerator.addJavaFileComment(interfaze);

        String rootInterface = introspectedTable
                .getTableConfigurationProperty(PropertyRegistry.ANY_ROOT_INTERFACE);
        if (!stringHasValue(rootInterface)) {
            rootInterface = context.getJavaClientGeneratorConfiguration()
                    .getProperty(PropertyRegistry.ANY_ROOT_INTERFACE);
        }

        if (stringHasValue(rootInterface)) {
            FullyQualifiedJavaType fqjt = new FullyQualifiedJavaType(
                    rootInterface);
            interfaze.addSuperInterface(fqjt);
            interfaze.addImportedType(fqjt);
        }
        interfaze.addImportedType(new FullyQualifiedJavaType("com.github.pagehelper.PageInfo"));
        /*interfaze.addImportedType(new FullyQualifiedJavaType(introspectedTable.getRules().calculateAllFieldsClass().getPackageName()
                + ".bean." + introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "OutputDTO"));*/
        interfaze.addImportedType(new FullyQualifiedJavaType(context.getJavaServiceGeneratorConfiguration().getDtoDirectory() +introspectedTable.getRules().calculateAllFieldsClass().getShortName()+"OutputDTO"));

        addListMethod(interfaze);
        addInsertBatchMethod(interfaze);
        addGetMethod(interfaze);
        addSaveMethod(interfaze);
        addDeleteMethod(interfaze);
        addUpdateMethod(interfaze);

        List<CompilationUnit> answer = new ArrayList<CompilationUnit>();
      /*  if (context.getPlugins().clientGenerated(interfaze,
                introspectedTable)) {
            answer.add(interfaze);
        }*/
        answer.add(interfaze);
        List<CompilationUnit> extraCompilationUnits = getExtraCompilationUnits();
        if (extraCompilationUnits != null) {
            answer.addAll(extraCompilationUnits);
        }

        return answer;
    }
    public void addListMethod(Interface interfaze){
        FullyQualifiedJavaType mapperType= new FullyQualifiedJavaType(introspectedTable.getMyBatis3JavaMapperType());
        Method method = new Method("list");
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName("list");
        method.setAbstract(true);
        if(introspectedTable.getRules().generateListParamClass()){
            FullyQualifiedJavaType listType = new FullyQualifiedJavaType(context.getJavaServiceGeneratorConfiguration().getDtoDirectory() + introspectedTable.getRules().calculateAllFieldsClass().getShortName() + "InputDTO");

            method.addParameter(0,new Parameter(listType,"inputParam"));
            method.addParameter(1,new Parameter(new FullyQualifiedJavaType("Integer"),"pageNo"));
            method.addParameter(2,new Parameter(new FullyQualifiedJavaType("Integer"),"pageSize"));
            interfaze.addImportedType(listType);
        }
        FullyQualifiedJavaType resultType = new FullyQualifiedJavaType("com.github.pagehelper.PageInfo");
        interfaze.addImportedType(resultType);
        //resultType.addTypeArgument(introspectedTable.getRules().calculateAllFieldsClass());
        resultType.addTypeArgument(new FullyQualifiedJavaType(introspectedTable.getRules().calculateAllFieldsClass().getShortName()+ "OutputDTO"));
        method.setReturnType(resultType);
        interfaze.addMethod(method);
    }

    public String getType(){
        return introspectedTable.getRules().calculateAllFieldsClass().getPackageName()
                + "." + introspectedTable.getRules().calculateAllFieldsClass().getShortName();
    }


    public void addGetMethod(Interface interfaze){
        Method method = new Method("get");
        method.setAbstract(true);
        // method.setReturnType(introspectedTable.getRules().calculateAllFieldsClass());
        FullyQualifiedJavaType type = new FullyQualifiedJavaType(introspectedTable.getRules().calculateAllFieldsClass().getShortName()+ "OutputDTO");
        //type.addTypeArgument();
        method.setReturnType(type);
        method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(),"id"));
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName("get");
        interfaze.addMethod(method);
    }
    public void addSaveMethod(Interface interfaze){
        Method method = new Method("save");
        method.addParameter(new Parameter(introspectedTable.getRules().calculateAllFieldsClass(),"toDB"));
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName("save");
        method.setAbstract(true);
        interfaze.addMethod(method);
    }
    public void addDeleteMethod(Interface interfaze){
        Method method = new Method("delete");
        method.addParameter(new Parameter(FullyQualifiedJavaType.getStringInstance(),"id"));
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName("delete");
        method.setAbstract(true);
        interfaze.addMethod(method);
    }
    public void addUpdateMethod(Interface interfaze){
        Method method = new Method("update");
        method.addParameter(new Parameter(introspectedTable.getRules().calculateAllFieldsClass(),"toDB"));
        method.setVisibility(JavaVisibility.PUBLIC);
        method.setName("update");
        method.setAbstract(true);
        interfaze.addMethod(method);
    }
    protected void initializeAndExecuteGenerator(
            AbstractJavaMapperMethodGenerator methodGenerator,
            Interface interfaze) {
        methodGenerator.setContext(context);
        methodGenerator.setIntrospectedTable(introspectedTable);
        methodGenerator.setProgressCallback(progressCallback);
        methodGenerator.setWarnings(warnings);
        methodGenerator.addInterfaceElements(interfaze);
    }
    protected void addInsertBatchMethod(Interface interfaze) {
        if (introspectedTable.getRules().generateInsertBatch()) {
            AbstractJavaMapperMethodGenerator methodGenerator = new InsertBatchMethodGenerator(true);
            initializeAndExecuteGenerator(methodGenerator, interfaze);
        }
    }


    public List<CompilationUnit> getExtraCompilationUnits() {
        return Collections.emptyList();
    }

    @Override
    public AbstractXmlGenerator getMatchedXMLGenerator() {
        return new XMLMapperGenerator();
    }
}
